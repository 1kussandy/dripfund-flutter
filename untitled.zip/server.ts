import express from "express";
import cors from "cors";
import path from "path";
import fs from "fs";
import os from "os";
import dotenv from "dotenv";
import { createServer as createViteServer } from "vite";
import pg from "pg";

dotenv.config();

const app = express();
const PORT = 3000;

app.use(cors());
app.use(express.json());

const pool = new pg.Pool({
  host: process.env.DB_HOST || "localhost",
  port: parseInt(process.env.DB_PORT || "5432"),
  user: process.env.DB_USER || "postgres",
  password: process.env.DB_PASSWORD || "",
  database: process.env.DB_NAME || "control_tower",
  max: 10,
  idleTimeoutMillis: 30000,
  connectionTimeoutMillis: 3000,
});

let useDbFallback = false;
const WORKSPACE_FALLBACK_FILE = path.join(process.cwd(), "db_fallback.json");
const FALLBACK_FILE = path.join(os.tmpdir(), "db_fallback_ten1.json");

// Intelligently seed the OS temp fallback from the workspace copy if it exists and temp doesn't
try {
  if (!fs.existsSync(FALLBACK_FILE) && fs.existsSync(WORKSPACE_FALLBACK_FILE)) {
    fs.copyFileSync(WORKSPACE_FALLBACK_FILE, FALLBACK_FILE);
  }
} catch (e) {
  console.error("Migration of local fallback schema to system temp folder failed:", e);
}

function readFallback() {
  try {
    if (fs.existsSync(FALLBACK_FILE)) {
      return JSON.parse(fs.readFileSync(FALLBACK_FILE, "utf8"));
    }
  } catch (e) {
    console.error("Error reading fallback file:", e);
  }
  return {
    settings: { active_mode: "INBOUND", active_shift: "FHD" },
    associates: [],
    permissions: [],
    lines: [],
    stations: [],
    paths: [],
    assignments: {},
    attendance: [],
    certifications: []
  };
}

function writeFallback(data: any) {
  try {
    fs.writeFileSync(FALLBACK_FILE, JSON.stringify(data, null, 2), "utf8");
  } catch (e) {
    console.error("Error writing fallback file:", e);
  }
}

// Ensure database tables exist or fallback
async function initTables() {
  try {
    const client = await pool.connect();
    await client.query(`
      CREATE TABLE IF NOT EXISTS settings (key TEXT PRIMARY KEY, value TEXT);
      CREATE TABLE IF NOT EXISTS shifts (code TEXT PRIMARY KEY, name TEXT, start_hour INTEGER, start_minute INTEGER, end_hour INTEGER, end_minute INTEGER, days TEXT);
      CREATE TABLE IF NOT EXISTS departments (id SERIAL PRIMARY KEY, name TEXT UNIQUE, mode TEXT, active BOOLEAN DEFAULT true);
      CREATE TABLE IF NOT EXISTS paths (id SERIAL PRIMARY KEY, name TEXT UNIQUE, dept_id INTEGER, role_type TEXT, mode TEXT, rotation_hours INTEGER, priority INTEGER DEFAULT 5, max_capacity INTEGER, sort_order INTEGER, active BOOLEAN DEFAULT true);
      CREATE TABLE IF NOT EXISTS lines (id SERIAL PRIMARY KEY, dept_id INTEGER, path_id INTEGER, name TEXT, side TEXT, sort_order INTEGER, active BOOLEAN DEFAULT true, active_half1 BOOLEAN DEFAULT true, active_half2 BOOLEAN DEFAULT true);
      CREATE TABLE IF NOT EXISTS stations (id SERIAL PRIMARY KEY, line_id INTEGER, name TEXT, side TEXT, station_number INTEGER, occupied BOOLEAN DEFAULT false, occupied_by TEXT, occupied_since BIGINT, active BOOLEAN DEFAULT true, active_half1 BOOLEAN DEFAULT true, active_half2 BOOLEAN DEFAULT true, status TEXT DEFAULT 'OPERATIONAL');
      CREATE TABLE IF NOT EXISTS associates (badge TEXT PRIMARY KEY, login TEXT UNIQUE, name TEXT, home_dept TEXT, manager TEXT, shift_code TEXT, operation_mode TEXT, default_dept TEXT DEFAULT 'INBOUND', current_path_id INTEGER, current_station_id INTEGER, current_path_start BIGINT, active BOOLEAN DEFAULT true, created_at TIMESTAMP DEFAULT NOW());
      CREATE TABLE IF NOT EXISTS permissions (badge TEXT, path_id INTEGER, lc_level INTEGER, PRIMARY KEY (badge, path_id));
      CREATE TABLE IF NOT EXISTS assignments (id SERIAL PRIMARY KEY, badge TEXT, path_id INTEGER, path_name TEXT, station_id INTEGER, station_name TEXT, line_name TEXT, assigned_at BIGINT, released_at BIGINT, half TEXT);
      CREATE TABLE IF NOT EXISTS admin_profiles (id SERIAL PRIMARY KEY, name TEXT, login TEXT UNIQUE, pin TEXT, role TEXT DEFAULT 'Manager', created_at BIGINT DEFAULT (EXTRACT(EPOCH FROM NOW())));
    `);
    client.release();
    console.log("PostgreSQL initialized successfully.");
  } catch (e: any) {
    console.warn("⚠️ PostgreSQL unavailable. Running in robust fallback JSON mode.", e.message);
    useDbFallback = true;
    const fb = readFallback();
    if (!fb.paths || fb.paths.length === 0) {
      // Seed default paths, lines, and stations
      const initLayout = buildDefaultFloor();
      fb.paths = initLayout.paths;
      fb.lines = initLayout.lines;
      fb.stations = initLayout.stations;
      writeFallback(fb);
    }
  }
}

// Standard structural seeding for floor layout fallback
function buildDefaultFloor() {
  const paths: any[] = [];
  const lines: any[] = [];
  const stations: any[] = [];
  let lid = 1, sid = 1;
  function addPath(pid: number, name: string, rt: string, dept: string, nLines: number, stPerSide: number) {
    paths.push({ id: pid, name, role_type: rt, department: dept, active: true, display_order: pid * 100, priority: 5 });
    for (let li = 1; li <= nLines; li++) {
      const lId = lid++;
      lines.push({ id: lId, path_id: pid, name: `Line ${li}`, active: true, active_half1: true, active_half2: true });
      for (let s = 1; s <= stPerSide; s++) {
        stations.push({ id: sid++, line_id: lId, path_id: pid, name: `${li}-${s * 2 - 1}`, side: "ODD", station_number: s * 2 - 1, active: true, active_half1: true, active_half2: true, status: "OPERATIONAL" });
        stations.push({ id: sid++, line_id: lId, path_id: pid, name: `${li}-${s * 2}`, side: "EVEN", station_number: s * 2, active: true, active_half1: true, active_half2: true, status: "OPERATIONAL" });
      }
    }
  }
  addPath(1, "CRETS Processing", "DIRECT", "INBOUND", 8, 8);
  addPath(2, "CRETS High Side", "DIRECT", "INBOUND", 2, 10);
  addPath(3, "WHD Processing", "DIRECT", "INBOUND", 4, 8);
  addPath(4, "Refurb Processing", "DIRECT", "INBOUND", 3, 8);
  addPath(5, "Tech Grading", "DIRECT", "INBOUND", 2, 8);
  addPath(6, "Problem Solve", "DIRECT", "INBOUND", 1, 5);
  addPath(7, "Super Solver", "DIRECT", "INBOUND", 1, 5);
  addPath(8, "Waterspider", "INDIRECT", "INBOUND", 1, 6);
  return { paths, lines, stations };
}

// ========== ENDPOINTS ==========

app.get("/api/system", async (req, res) => {
  if (useDbFallback) {
    const fb = readFallback();
    return res.json({
      mode: fb.settings.active_mode || "INBOUND",
      activeShift: fb.settings.active_shift || "FHD",
      shifts: [],
      totalAssoc: fb.associates.length,
      onFloor: Object.keys(fb.assignments).length,
      openStations: fb.stations.filter((s: any) => s.active && !s.occupied && s.status === "OPERATIONAL").length,
      filledStations: fb.stations.filter((s: any) => s.occupied).length
    });
  }
  res.json({ mode: "INBOUND", activeShift: "FHD", shifts: [], totalAssoc: 0, onFloor: 0, openStations: 0, filledStations: 0 });
});

app.post("/api/system/mode", async (req, res) => {
  const { mode } = req.body;
  if (useDbFallback) {
    const fb = readFallback();
    fb.settings.active_mode = mode;
    writeFallback(fb);
  }
  res.json({ success: true, mode });
});

app.post("/api/system/shift", async (req, res) => {
  const { shift } = req.body;
  if (useDbFallback) {
    const fb = readFallback();
    fb.settings.active_shift = shift;
    writeFallback(fb);
  }
  res.json({ success: true, shift });
});

app.get("/api/lines", async (req, res) => {
  if (useDbFallback) {
    const fb = readFallback();
    return res.json(fb.lines);
  }
  res.json([]);
});

app.get("/api/stations", async (req, res) => {
  if (useDbFallback) {
    const fb = readFallback();
    return res.json(fb.stations);
  }
  res.json([]);
});

app.patch("/api/lines/:id", async (req, res) => {
  const { id } = req.params;
  const { active_half1, active_half2 } = req.body;
  if (useDbFallback) {
    const fb = readFallback();
    const l = fb.lines.find((line: any) => line.id === parseInt(id));
    if (l) {
      if (active_half1 !== undefined) {
        l.active_half1 = active_half1;
        fb.stations.filter((s: any) => s.line_id === l.id).forEach((s: any) => { s.active_half1 = active_half1; });
      }
      if (active_half2 !== undefined) {
        l.active_half2 = active_half2;
        fb.stations.filter((s: any) => s.line_id === l.id).forEach((s: any) => { s.active_half2 = active_half2; });
      }
      writeFallback(fb);
      return res.json({ success: true });
    }
  }
  res.status(404).json({ error: "Line not found" });
});

app.patch("/api/stations/:id", async (req, res) => {
  const { id } = req.params;
  const { active_half1, active_half2 } = req.body;
  if (useDbFallback) {
    const fb = readFallback();
    const s = fb.stations.find((st: any) => st.id === parseInt(id));
    if (s) {
      if (active_half1 !== undefined) s.active_half1 = active_half1;
      if (active_half2 !== undefined) s.active_half2 = active_half2;
      writeFallback(fb);
      return res.json({ success: true });
    }
  }
  res.status(404).json({ error: "Station not found" });
});

app.get("/api/associates", async (req, res) => {
  if (useDbFallback) {
    const fb = readFallback();
    return res.json(fb.associates);
  }
  res.json([]);
});

app.post("/api/associates", async (req, res) => {
  if (useDbFallback) {
    const fb = readFallback();
    const assoc = { ...req.body, permissions: req.body.permissions || [] };
    fb.associates.push(assoc);
    writeFallback(fb);
    return res.json(assoc);
  }
  res.json({});
});

app.delete("/api/associates/:badge", async (req, res) => {
  const { badge } = req.params;
  if (useDbFallback) {
    const fb = readFallback();
    fb.associates = fb.associates.filter((a: any) => a.badge !== badge);
    writeFallback(fb);
    return res.json({ success: true });
  }
  res.json({ success: true });
});

app.post("/api/permissions", async (req, res) => {
  const { badge, path_id, lc_level } = req.body;
  if (useDbFallback) {
    const fb = readFallback();
    const assoc = fb.associates.find((a: any) => a.badge === badge);
    if (assoc) {
      const pathObj = fb.paths.find((p: any) => p.id === path_id);
      if (pathObj) {
        if (!assoc.permissions) assoc.permissions = [];
        const existing = assoc.permissions.find((p: any) => p.path_name === pathObj.name);
        if (existing) {
          existing.lc_level = lc_level;
        } else {
          assoc.permissions.push({ path_name: pathObj.name, lc_level });
        }
        writeFallback(fb);
        return res.json(assoc);
      }
    }
  }
  res.status(404).json({ error: "Not found" });
});

app.post("/api/reset-shift", async (req, res) => {
  if (useDbFallback) {
    const fb = readFallback();
    fb.assignments = {};
    fb.stations.forEach((s: any) => {
      s.occupied = false;
      s.occupied_by = null;
      s.active_half1 = true;
      s.active_half2 = true;
      s.status = "OPERATIONAL";
    });
    fb.lines.forEach((l: any) => {
      l.active_half1 = true;
      l.active_half2 = true;
    });
    writeFallback(fb);
  } else {
    try {
      await pool.query("DELETE FROM assignments");
      await pool.query("DELETE FROM settings WHERE key = 'placements'");
      await pool.query("UPDATE stations SET occupied = false, occupied_by = NULL, active_half1 = true, active_half2 = true, status = 'OPERATIONAL'");
      await pool.query("UPDATE lines SET active_half1 = true, active_half2 = true");
    } catch (e) {
      console.error(e);
    }
  }
  res.json({ success: true });
});

app.get("/api/placements", async (req, res) => {
  if (useDbFallback) {
    const fb = readFallback();
    return res.json({
      contextStations: fb.assignments?.contextStations || {},
      contextBadges: fb.assignments?.contextBadges || {},
      shiftAssignments: fb.assignments?.shiftAssignments || {}
    });
  } else {
    try {
      const dbRes = await pool.query("SELECT value FROM settings WHERE key = 'placements'");
      if (dbRes.rows.length) {
        return res.json(JSON.parse(dbRes.rows[0].value));
      }
    } catch (e) {
      console.error(e);
    }
    res.json({ contextStations: {}, contextBadges: {}, shiftAssignments: {} });
  }
});

app.post("/api/placements", async (req, res) => {
  const { contextStations, contextBadges, shiftAssignments } = req.body;
  if (useDbFallback) {
    const fb = readFallback();
    fb.assignments = { contextStations, contextBadges, shiftAssignments };
    writeFallback(fb);
  } else {
    try {
      const val = JSON.stringify({ contextStations, contextBadges, shiftAssignments });
      await pool.query(
        "INSERT INTO settings (key, value) VALUES ('placements', $1) ON CONFLICT (key) DO UPDATE SET value = EXCLUDED.value",
        [val]
      );
    } catch (e) {
      console.error(e);
    }
  }
  res.json({ success: true });
});

app.get("/api/floor-custom", async (req, res) => {
  res.json({ paths: [], lines: [], stations: [] });
});

app.get("/api/floor-custom-renames", async (req, res) => {
  res.json({ renames: {} });
});

// ========== START SERVER ==========
async function startServer() {
  await initTables();

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server listening on http://localhost:${PORT}`);
  });
}

startServer();
