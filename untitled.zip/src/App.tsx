import { useState, useEffect } from "react";
import { Associate, StationAssignment, Path, Line, Station } from "./types";

import { AdminGate } from "./components/AdminGate";
import { Kiosk } from "./components/Kiosk";
import { Dashboard } from "./components/Dashboard";
import { FloorMap } from "./components/FloorMap";
import { Permissions } from "./components/Permissions";
import { Associates } from "./components/Associates";
import { AssignHistory } from "./components/History";
import { SearchLookup } from "./components/Lookup";
import { Report } from "./components/Report";
import { Performance } from "./components/Performance";
import { Alerts } from "./components/Alerts";
import { Leaderboard } from "./components/Leaderboard";
import { Settings } from "./components/Settings";

const API = "/api";

// Shared common helper layout configurations
const INIT_PATHS: Path[] = [
  { id: 1, name: "CRETS Processing", role_type: "DIRECT", department: "INBOUND" },
  { id: 2, name: "CRETS High Side", role_type: "DIRECT", department: "INBOUND" },
  { id: 3, name: "WHD Processing", role_type: "DIRECT", department: "INBOUND" },
  { id: 4, name: "Refurb Processing", role_type: "DIRECT", department: "INBOUND" },
  { id: 5, name: "Tech Grading", role_type: "DIRECT", department: "INBOUND" },
  { id: 6, name: "Problem Solve", role_type: "DIRECT", department: "INBOUND" },
  { id: 7, name: "Super Solver", role_type: "DIRECT", department: "INBOUND" },
  { id: 8, name: "Waterspider", role_type: "INDIRECT", department: "INBOUND" },
  { id: 9, name: "Downstacker", role_type: "INDIRECT", department: "INBOUND" },
  { id: 10, name: "Unloader", role_type: "INDIRECT", department: "INBOUND" },
  { id: 11, name: "Upstacker", role_type: "INDIRECT", department: "INBOUND" },
  { id: 12, name: "Cage Builder", role_type: "INDIRECT", department: "INBOUND" },
  { id: 13, name: "Pick Driver", role_type: "DIRECT", department: "OUTBOUND" },
  { id: 14, name: "Stow Driver", role_type: "DIRECT", department: "OUTBOUND" },
  { id: 15, name: "Rebin Processing", role_type: "DIRECT", department: "OUTBOUND" },
  { id: 16, name: "Pack Processing", role_type: "DIRECT", department: "OUTBOUND" },
  { id: 17, name: "Problem Solve", role_type: "DIRECT", department: "OUTBOUND" },
  { id: 18, name: "Super Solver", role_type: "DIRECT", department: "OUTBOUND" }
];

const INIT_LINES: Line[] = [
  { id: 1, path_id: 1, name: "Line 1", active: true, active_half1: true, active_half2: true },
  { id: 2, path_id: 1, name: "Line 2", active: true, active_half1: true, active_half2: true },
  { id: 3, path_id: 1, name: "Line 3", active: true, active_half1: true, active_half2: true },
  { id: 4, path_id: 1, name: "Line 4", active: true, active_half1: true, active_half2: true },
  { id: 5, path_id: 1, name: "Line 5", active: true, active_half1: true, active_half2: true },
  { id: 6, path_id: 1, name: "Line 6", active: true, active_half1: true, active_half2: true },
  { id: 7, path_id: 1, name: "Line 7", active: true, active_half1: true, active_half2: true },
  { id: 8, path_id: 1, name: "Line 8", active: true, active_half1: true, active_half2: true },
  { id: 9, path_id: 2, name: "High Side Line 1", active: true, active_half1: true, active_half2: true },
  { id: 10, path_id: 2, name: "High Side Line 2", active: true, active_half1: true, active_half2: true }
];

const INIT_STATIONS: Station[] = [];
// Generate Stations
for (let line = 1; line <= 8; line++) {
  for (let s = 1; s <= 8; s++) {
    INIT_STATIONS.push({
      id: (line * 100) + s,
      line_id: line,
      path_id: 1,
      name: `${line}-${s * 2 - 1}`,
      side: "ODD",
      station_number: s * 2 - 1,
      active: true,
      active_half1: true,
      active_half2: true,
      status: "OPERATIONAL"
    });
    INIT_STATIONS.push({
      id: (line * 100) + s + 20,
      line_id: line,
      path_id: 1,
      name: `${line}-${s * 2}`,
      side: "EVEN",
      station_number: s * 2,
      active: true,
      active_half1: true,
      active_half2: true,
      status: "OPERATIONAL"
    });
  }
}
for (let hs = 1; hs <= 2; hs++) {
  const lineId = hs + 8;
  for (let s = 1; s <= 10; s++) {
    INIT_STATIONS.push({
      id: (lineId * 100) + s,
      line_id: lineId,
      path_id: 2,
      name: `HS${hs}-${s}`,
      side: s % 2 === 0 ? "EVEN" : "ODD",
      station_number: s,
      active: true,
      active_half1: true,
      active_half2: true,
      status: "OPERATIONAL"
    });
  }
}

// Client Replicated Persistence
let contextStations: any = {};
let contextBadges: any   = {};
let shiftAssignments: any = {};
let weekHistory: any      = {};

function getDisplayRoleName(pathName: string, dept: string) {
  if (!pathName) return "–";
  const u = pathName.toUpperCase();
  const isIndirect = u.includes("WATERSPIDER") || u.includes("DOWNSTACKER") || u.includes("UNLOADER") || u.includes("UPSTACKER") || u.includes("CAGE");
  if (!isIndirect) return pathName;
  const prefix = dept === "INBOUND" ? "IB " : "OB ";
  return prefix + pathName;
}

const isInd = (p: string | null | undefined) => {
  if (!p) return false;
  const u = String(p).toUpperCase();
  return u.includes("WATERSPIDER") || u.includes("DOWNSTACKER") || u.includes("UNLOADER") || u.includes("UPSTACKER") || u.includes("CAGE");
};

function getAssociateHistory(badge: string) {
  const list: any[] = [];
  const sortedKeys = Object.keys(shiftAssignments).sort((a, b) => {
    const dateA = a.split("|")[1] || "";
    const dateB = b.split("|")[1] || "";
    return new Date(dateA).getTime() - new Date(dateB).getTime();
  });

  sortedKeys.forEach(sKey => {
    const parts = sKey.split("|");
    if (parts.length < 3) return;
    const entryDept = parts[0];
    const entryDateStr = parts[1];
    const entryShiftType = parts[2];

    const placement = shiftAssignments[sKey]?.[badge];
    if (placement) {
      if (placement.half1) {
        list.push({
          date: entryDateStr,
          dept: entryDept,
          shiftType: entryShiftType,
          roleType: placement.half1.roleType,
          path: placement.half1.path,
          half: "half1"
        });
      }
      if (placement.half2) {
        list.push({
          date: entryDateStr,
          dept: entryDept,
          shiftType: entryShiftType,
          roleType: placement.half2.roleType,
          path: placement.half2.path,
          half: "half2"
        });
      }
    }
  });

  return list;
}

function consec3Indirect(badge: string, dept: string) {
  const h = getAssociateHistory(badge).filter((x: any) => !dept || x.dept === dept);
  return h.length >= 3 && h.slice(-3).every((x: any) => x.roleType === "INDIRECT");
}

function scoreOnePath(assoc: any, pathName: string, dept: string, targetDateStr?: string, floorPaths: any[] = []) {
  const canon = pathName;
  const perm = assoc.permissions?.find((p: any) => p.path_name === canon);
  if (!perm) return null;
  if (isInd(pathName) && consec3Indirect(assoc.badge, dept)) return null;

  let yd = 0; // Hours in this path yesterday
  let wk = 0; // Hours in this path in the last 21 days
  let tot = 0; // Total hours worked in any path in the last 21 days
  let todayHoursInPath = 0; // Hours in this path today so far (e.g. from H1 evaluating H2)

  if (targetDateStr) {
    const targetDate = new Date(targetDateStr);
    const targetTime = targetDate.getTime();
    const oneDayMs = 24 * 60 * 60 * 1000;

    const yesterdayDateObj = new Date(targetTime - oneDayMs);
    const yesterdayDateStr = yesterdayDateObj.toISOString().split("T")[0];

    Object.entries(shiftAssignments).forEach(([sKey, badgeMap]: [string, any]) => {
      const parts = sKey.split("|");
      if (parts.length < 3) return;
      const entryDateStr = parts[1];

      const entryTime = new Date(entryDateStr).getTime();
      const diffMs = targetTime - entryTime;
      const diffDays = diffMs / oneDayMs;

      const placement = badgeMap[assoc.badge];
      if (!placement) return;

      const h1Path = placement.half1?.path;
      const h2Path = placement.half2?.path;

      if (entryDateStr === yesterdayDateStr) {
        if (h1Path === pathName) yd += 5;
        if (h2Path === pathName) yd += 5;
      }

      // Roll up last 21 days (non-inclusive of targetDate itself)
      if (diffDays > 0 && diffDays <= 21) {
        if (h1Path) {
          tot += 5;
          if (h1Path === pathName) wk += 5;
        }
        if (h2Path) {
          tot += 5;
          if (h2Path === pathName) wk += 5;
        }
      }

      if (entryDateStr === targetDateStr) {
        if (h1Path === pathName) todayHoursInPath += 5;
      }
    });
  }

  // 1. Yesterday Penalty: -40 to +20 (biggest factor — drives rotation)
  let ydPts = 20; // Incentive bonus if they didn't work same path yesterday
  if (yd >= 10) ydPts = -40;
  else if (yd === 5) ydPts = -20;

  // 2. Week Share Bonus: 0 to +30 (fairness across the week)
  const share = wk / (tot || 1);
  const wkPts = Math.round((1 - share) * 30);

  // 3. LC level: +8 to +40 (qualification fit)
  const lcPts = (perm.lc_level || 1) * 8;

  // 4. Path priority: +5 to +10 (business need)
  const fpObj = floorPaths.find(p => p.name === pathName);
  const pathPriority = fpObj ? (fpObj.priority || 5) : 5;
  const prPts = Math.max(5, Math.min(10, pathPriority));

  // 5. Breadth bonus: +2 to +30 (flexibility value)
  const numPerms = (assoc.permissions || []).length;
  const bPts = Math.max(2, Math.min(30, 2 + (numPerms - 1) * 4));

  // 6. Today penalty: 0 to -15 (approaching rotation cap)
  let todayPenalty = 0;
  const cap = fpObj?.rotation_hours || 10;
  if (todayHoursInPath > 0) {
    if (todayHoursInPath >= cap) {
      todayPenalty = -15;
    } else if (todayHoursInPath >= cap * 0.5) {
      todayPenalty = -5;
    }
  }

  const total = Math.max(0, ydPts + wkPts + lcPts + prPts + bPts + todayPenalty);
  let rotationHours = fpObj ? (fpObj.rotation_hours || 10) : 10;

  return {
    score: +total.toFixed(1),
    lc: perm.lc_level,
    roleType: isInd(pathName) ? "INDIRECT" : "DIRECT",
    rotationHours: rotationHours,
    breakdown: [
      { factor: "Yesterday Penalty/Bonus", pts: ydPts, detail: yd > 0 ? `Penalty for doing ${yd}h of same path yesterday: ${ydPts} pts` : "No same path yesterday (Rotation incentive: +20 pts)" },
      { factor: "Week Work Share", pts: wkPts, detail: `${wk}h worked in path out of ${tot}h total last 21d (${Math.round(share * 100)}% share: +${wkPts} pts)` },
      { factor: "Learning Curve Fit", pts: lcPts, detail: `L${perm.lc_level}/5 proficiency (+${lcPts} pts)` },
      { factor: "Path Priority", pts: prPts, detail: `Priority ${pathPriority} (+${prPts} pts)` },
      { factor: "Breadth/Flexibility", pts: bPts, detail: `${numPerms} qualified paths (+${bPts} pts)` },
      { factor: "Today Rotation Cap", pts: todayPenalty, detail: todayHoursInPath > 0 ? `${todayHoursInPath}h already worked in path today (${todayPenalty} pts)` : "No same path workload today (0 pts)" }
    ]
  };
}

function getShiftInfoText(dateVal: Date | string) {
  const dateObj = dateVal instanceof Date ? dateVal : new Date(dateVal + "T00:00:00");
  const day = dateObj.getDay(); // 0 is Sunday, 3 is Wednesday, 6 is Saturday
  const days = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"];
  const dayName = days[day];

  if (day >= 0 && day <= 2) {
    return {
      dayName,
      dayShift: "FHD (Front Half Days)",
      nightShift: "FHN (Front Half Nights)",
      overlapping: false
    };
  }
  if (day === 3) {
    return {
      dayName,
      dayShift: "FHD & BHD (Overlapping Days)",
      nightShift: "FHN & BHN (Overlapping Nights)",
      overlapping: true
    };
  }
  return {
    dayName,
    dayShift: "BHD (Back Half Days)",
    nightShift: "BHN (Back Half Nights)",
    overlapping: false
  };
}

function getHalf(staffDate: Date | string, shiftCode: string, dept: string) {
  const now = new Date();
  const ds = staffDate instanceof Date ? staffDate.toISOString().split("T")[0] : staffDate;
  const todayStr = now.toISOString().split("T")[0];
  
  if (ds !== todayStr) return "half1";

  const hr = now.getHours();
  const min = now.getMinutes();
  const totalMins = hr * 60 + min;

  const isNight = shiftCode === "NIGHT" || shiftCode === "FHN" || shiftCode === "BHN" || shiftCode.endsWith("N");
  const isOutbound = String(dept).toUpperCase() === "OUTBOUND";

  if (!isNight) {
    if (isOutbound) {
      // OUTBOUND Day (FHD/BHD): 7:15 AM to 5:45 PM. Half split: 12:30 PM (750 minutes)
      return totalMins < 750 ? "half1" : "half2";
    } else {
      // INBOUND Day (FHD/BHD): 7:00 AM to 5:30 PM. Half split: 12:15 PM (735 minutes)
      return totalMins < 735 ? "half1" : "half2";
    }
  } else {
    if (isOutbound) {
      // OUTBOUND Night (FHN/BHN): 6:45 PM (1125 mins) to 5:15 AM (315 mins next day). Half split: 12:00 AM (midnight / 0 mins)
      if (totalMins >= 1125 || totalMins < 0) {
        return "half1";
      } else {
        return "half2";
      }
    } else {
      // INBOUND Night (FHN/BHN): 6:30 PM (1110 mins) to 5:00 AM (300 mins next day). Half split: 11:45 PM (1425 mins)
      if (totalMins >= 1110 && totalMins < 1425) {
        return "half1";
      } else {
        return "half2";
      }
    }
  }
}

function shiftKey(dept: string, dateStr: string, shiftType: string) {
  return `${dept}|${dateStr}|${shiftType}`;
}

function cleanupOldHistory() {
  const today = new Date();
  const limitTime = 21 * 24 * 60 * 60 * 1000; // 21 days in ms

  // Clean shiftAssignments
  Object.keys(shiftAssignments).forEach(key => {
    const parts = key.split("|");
    if (parts.length >= 2) {
      const datePart = parts[1]; // e.g. "2026-06-13"
      const entryTime = new Date(datePart).getTime();
      if (!isNaN(entryTime) && (today.getTime() - entryTime) > limitTime) {
        delete shiftAssignments[key];
      }
    }
  });

  // Clean contextStations
  Object.keys(contextStations).forEach(key => {
    const parts = key.split("|");
    if (parts.length >= 1) {
      const datePart = parts[0]; // e.g. "2026-06-13"
      const entryTime = new Date(datePart).getTime();
      if (!isNaN(entryTime) && (today.getTime() - entryTime) > limitTime) {
        delete contextStations[key];
      }
    }
  });

  // Clean contextBadges
  Object.keys(contextBadges).forEach(key => {
    const parts = key.split("|");
    if (parts.length >= 1) {
      const datePart = parts[0]; // e.g. "2026-06-13"
      const entryTime = new Date(datePart).getTime();
      if (!isNaN(entryTime) && (today.getTime() - entryTime) > limitTime) {
        delete contextBadges[key];
      }
    }
  });
}

function savePlacementsRaw() {
  cleanupOldHistory();
  fetch("/api/placements", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contextStations,
      contextBadges,
      shiftAssignments
    })
  }).catch(() => {});
}

function getStationAssignment(contextKey: string, stationId: number, half: string) {
  return contextStations[contextKey]?.[stationId]?.[half] || null;
}

function setStationAssignment(contextKey: string, stationId: number, half: string, assignment: any) {
  if (!contextStations[contextKey]) contextStations[contextKey] = {};
  if (!contextStations[contextKey][stationId]) contextStations[contextKey][stationId] = {};
  contextStations[contextKey][stationId][half] = assignment;
  savePlacementsRaw();
}

function clearStationAssignment(contextKey: string, stationId: number, half: string) {
  const currentAss = contextStations[contextKey]?.[stationId]?.[half];
  if (currentAss && currentAss.badge) {
    if (contextBadges[contextKey]?.[currentAss.badge]) {
      delete contextBadges[contextKey][currentAss.badge][half];
    }
    const parts = contextKey.split("|");
    if (parts.length >= 3) {
      const dateStr = parts[0];
      const shiftType = parts[1];
      const dept = parts[2];
      const sKey = `${dept}|${dateStr}|${shiftType}`;
      if (shiftAssignments[sKey]?.[currentAss.badge]) {
        if (half === "half1") {
          shiftAssignments[sKey][currentAss.badge].half1 = null;
        } else {
          shiftAssignments[sKey][currentAss.badge].half2 = null;
        }
        if (!shiftAssignments[sKey][currentAss.badge].half1 && !shiftAssignments[sKey][currentAss.badge].half2) {
          delete shiftAssignments[sKey][currentAss.badge];
        }
      }
    }
  }
  if (contextStations[contextKey]?.[stationId]) {
    delete contextStations[contextKey][stationId][half];
  }
  savePlacementsRaw();
}

function getBadgeAssignment(contextKey: string, badge: string, half: string) {
  return contextBadges[contextKey]?.[badge]?.[half] || null;
}

function setBadgeAssignment(contextKey: string, badge: string, half: string, stationId: number) {
  if (!contextBadges[contextKey]) contextBadges[contextKey] = {};
  if (!contextBadges[contextKey][badge]) contextBadges[contextKey][badge] = {};
  contextBadges[contextKey][badge][half] = stationId;
  savePlacementsRaw();
}

function clearContextAssignments(contextKey: string) {
  delete contextStations[contextKey];
  delete contextBadges[contextKey];
  savePlacementsRaw();
}





let mockAssocs: Associate[] = [
  { badge: "101181", login: "moberete", name: "Mory Berete", home_dept: "CRETS Processing", manager: "Johnson, Lainie", shift_code: "FHD", operation_mode: "BOTH", permissions: [{ path_name: "CRETS Processing", lc_level: 5 }, { path_name: "CRETS High Side", lc_level: 4 }] },
  { badge: "172099", login: "mroblero", name: "Manuel Roblero", home_dept: "Warehouse Deals", manager: "Moore, Daniel", shift_code: "BHD", operation_mode: "BOTH", permissions: [{ path_name: "WHD Processing", lc_level: 5 }, { path_name: "Tech Grading", lc_level: 4 }] },
  { badge: "105011", login: "pblakeld", name: "Patricia Blake", home_dept: "Warehouse Deals", manager: "Schuh, Steve", shift_code: "FHD", operation_mode: "BOTH", permissions: [{ path_name: "WHD Processing", lc_level: 5 }, { path_name: "Refurb Processing", lc_level: 4 }] },
  { badge: "115361", login: "nickomil", name: "Nick Miller", home_dept: "CRETS Processing", manager: "Moore, Daniel", shift_code: "FHD", operation_mode: "INBOUND", permissions: [{ path_name: "CRETS Processing", lc_level: 4 }] },
  { badge: "11873356", login: "dhunroha", name: "Rohan Dhungana", home_dept: "CRETS Processing", manager: "Metz, Lenny", shift_code: "FHN", operation_mode: "INBOUND", permissions: [{ path_name: "Tech Grading", lc_level: 5 }, { path_name: "CRETS High Side", lc_level: 3 }] },
  { badge: "500001", login: "asmith", name: "Amanda Smith", home_dept: "CRETS Processing", manager: "Johnson, Lainie", shift_code: "FHD", operation_mode: "INBOUND", permissions: [{ path_name: "CRETS Processing", lc_level: 4 }] },
  { badge: "600001", login: "pdriver", name: "Peter Driver", home_dept: "Outbound", manager: "Watson, John", shift_code: "FHD", operation_mode: "OUTBOUND", permissions: [{ path_name: "Pick Driver", lc_level: 5 }] },
  { badge: "600002", login: "sdriver", name: "Sally Driver", home_dept: "Outbound", manager: "Watson, John", shift_code: "FHD", operation_mode: "OUTBOUND", permissions: [{ path_name: "Stow Driver", lc_level: 5 }, { path_name: "Pack Processing", lc_level: 4 }] },
  { badge: "600003", login: "mpacker", name: "Marcus Packer", home_dept: "Outbound", manager: "Watson, John", shift_code: "BHD", operation_mode: "OUTBOUND", permissions: [{ path_name: "Pack Processing", lc_level: 5 }] },
  { badge: "600004", login: "lpacker", name: "Lucy Packer", home_dept: "Outbound", manager: "Watson, John", shift_code: "BHD", operation_mode: "OUTBOUND", permissions: [{ path_name: "Pack Processing", lc_level: 4 }] }
];

const fmtTime = () => new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });

export default function App() {
  const [tab, setTab] = useState("kiosk");
  
  // Floor Map Reactive Network State
  const [floorPaths, setFloorPaths] = useState<Path[]>(() => [...INIT_PATHS]);
  const [floorLines, setFloorLines] = useState<Line[]>(() => [...INIT_LINES]);
  const [floorStations, setFloorStations] = useState<Station[]>(() => [...INIT_STATIONS]);

  const SA = (sid: number, half: string) => {
    const s = floorStations.find(x => x.id === sid);
    if (!s) return false;
    const l = floorLines.find(x => x.id === s.line_id);
    if (!l) return false;
    const lineActive = half === "half1" ? l.active_half1 !== false : l.active_half2 !== false;
    if (!lineActive) return false;
    return half === "half1" ? s.active_half1 !== false : s.active_half2 !== false;
  };

  const LA = (lid: number, half: string) => {
    const l = floorLines.find(x => x.id === lid);
    if (!l) return false;
    return half === "half1" ? l.active_half1 !== false : l.active_half2 !== false;
  };

  const isPathOpenForHalf = (pathId: number, half: string, dept: string, dateStr: string, shiftType: string) => {
    const lineIds = floorLines.filter(l => l.path_id === pathId && LA(l.id, half)).map(l => l.id);
    if (!lineIds.length) return false;
    const openSts = floorStations.filter(s => {
      if (!lineIds.includes(s.line_id)) return false;
      if (!SA(s.id, half)) return false;
      if (s.status !== "OPERATIONAL") return false;
      const occupied = getStationAssignment(`${dateStr}|${shiftType}|${dept}`, s.id, half);
      return !occupied;
    });
    return openSts.length > 0;
  };

  const openStForPath = (pathId: number, half: string, dept: string, dateStr: string, shiftType: string) => {
    const ctx = `${dateStr}|${shiftType}|${dept}`;
    const path = floorPaths.find(p => p.id === pathId && p.active !== false);
    if (!path) return null;
    const lineIds = floorLines.filter(l => l.path_id === pathId && LA(l.id, half)).map(l => l.id);
    if (!lineIds.length) return null;
    const cands = floorStations.filter(s => {
      if (!lineIds.includes(s.line_id)) return false;
      if (!SA(s.id, half)) return false;
      if (s.status !== "OPERATIONAL") return false;
      const occupied = getStationAssignment(ctx, s.id, half);
      return !occupied;
    });
    if (!cands.length) return null;
    const pick = cands[Math.floor(Math.random() * cands.length)];
    return { ...pick, line_name: floorLines.find(l => l.id === pick.line_id)?.name || "" };
  };

  const runScanWithLaborShare = (
    badge: string,
    staffDate: any,
    shiftType: string,
    laborShareEnabled: boolean,
    laborShareCount: number,
    crossDeptUsage: any,
    getCrossDeptUsed: any,
    incrementCrossDept: any,
    contextKey: string
  ) => {
    const assoc = mockAssocs.find(a => a.badge === badge || a.login === badge.toLowerCase());
    if (!assoc) return null;

    let targetDept = assoc.operation_mode === "BOTH" ? (assoc.default_dept || "INBOUND") : assoc.operation_mode;
    let isCrossDept = false;

    if (assoc.operation_mode === "BOTH" && laborShareEnabled) {
      const defaultDept = assoc.default_dept || "INBOUND";
      const otherDept = defaultDept === "INBOUND" ? "OUTBOUND" : "INBOUND";
      const used = getCrossDeptUsed(contextKey);
      if (laborShareCount === 0 || used < laborShareCount) {
        const hasOtherDeptPerm = (assoc.permissions || []).some((p: any) => {
          const path = floorPaths.find(fp => fp.name === p.path_name);
          return path && path.department === otherDept;
        });
        if (hasOtherDeptPerm) {
          targetDept = otherDept;
          isCrossDept = true;
        }
      }
    }

    const dateStr = staffDate instanceof Date ? staffDate.toISOString().split("T")[0] : staffDate;
    const half = getHalf(staffDate, shiftType, targetDept);
    const sKey = shiftKey(targetDept, dateStr, shiftType);
    const ctx = `${dateStr}|${shiftType}|${targetDept}`;

    // 1. Context Placement Synchronization
    const assignedStIdH1 = getBadgeAssignment(ctx, assoc.badge, "half1");
    const assignedStIdH2 = getBadgeAssignment(ctx, assoc.badge, "half2");

    const activeH1Asn = assignedStIdH1 ? getStationAssignment(ctx, assignedStIdH1, "half1") : null;
    const activeH2Asn = assignedStIdH2 ? getStationAssignment(ctx, assignedStIdH2, "half2") : null;

    let h1: any = null;
    let h2: any = null;

    if (activeH1Asn) {
      const stObj = floorStations.find(s => s.id === assignedStIdH1);
      h1 = {
        path: activeH1Asn.path,
        station: stObj ? { ...stObj, line_name: floorLines.find(l => l.id === stObj.line_id)?.name || "" } : null,
        score: 5,
        lc: 5,
        roleType: activeH1Asn.roleType || "MANUAL",
        rotationHours: 10,
        breakdown: [],
        allScores: []
      };
    }

    if (activeH2Asn) {
      const stObj = floorStations.find(s => s.id === assignedStIdH2);
      h2 = {
        path: activeH2Asn.path,
        station: stObj ? { ...stObj, line_name: floorLines.find(l => l.id === stObj.line_id)?.name || "" } : null,
        score: 5,
        lc: 5,
        roleType: activeH2Asn.roleType || "MANUAL",
        rotationHours: 10,
        breakdown: [],
        allScores: []
      };
    }

    if (activeH1Asn && activeH2Asn) {
      return {
        associate: assoc,
        path: h1?.path || "SEE ADMIN",
        station: h1?.station,
        score: h1?.score || 0,
        lc: h1?.lc || 0,
        roleType: h1?.roleType || "DIRECT",
        rotationHours: h1?.rotationHours || 10,
        breakdown: h1?.breakdown || [],
        allScores: [],
        method: "RECALL",
        isRecall: true,
        half,
        half1: h1,
        half2: h2,
        consec3: consec3Indirect(assoc.badge, targetDept),
        dept: targetDept,
        assignedDept: targetDept
      };
    }

    const scored = floorPaths
      .filter(fp => fp.department === targetDept)
      .map(fp => {
        const s = scoreOnePath(assoc, fp.name, targetDept, dateStr, floorPaths);
        if (!s) return null;
        return { path: fp.name, ...s, pathObj: fp };
      })
      .filter(Boolean)
      .sort((a, b) => b.score - a.score);

    if (!scored.length) {
      return {
        associate: assoc,
        path: "SEE ADMIN",
        station: null,
        score: 0,
        lc: 0,
        breakdown: [],
        allScores: [],
        reason: "No qualified path permissions configured. Access Permissions tab.",
        method: "AUTO",
        isRecall: false,
        half,
        dept: targetDept,
        assignedDept: targetDept
      };
    }

    let chosen: any = null;
    let isOpenH1 = false;
    let isOpenH2 = false;

    // Evaluate required halves
    const needH1 = !activeH1Asn;
    const needH2 = !activeH2Asn;

    for (const item of scored) {
      const h1Available = needH1 ? isPathOpenForHalf(item.pathObj.id, "half1", targetDept, dateStr, shiftType) : true;
      const h2Available = needH2 ? isPathOpenForHalf(item.pathObj.id, "half2", targetDept, dateStr, shiftType) : true;
      if (h1Available && h2Available) {
        chosen = item;
        isOpenH1 = needH1 ? h1Available : false;
        isOpenH2 = needH2 ? h2Available : false;
        break;
      }
    }

    if (!chosen) {
      for (const item of scored) {
        const h1Available = needH1 && isPathOpenForHalf(item.pathObj.id, "half1", targetDept, dateStr, shiftType);
        const h2Available = needH2 && isPathOpenForHalf(item.pathObj.id, "half2", targetDept, dateStr, shiftType);
        if (h1Available || h2Available) {
          chosen = item;
          isOpenH1 = h1Available;
          isOpenH2 = h2Available;
          break;
        }
      }
    }

    if (chosen) {
      if (needH1) {
        if (isOpenH1) {
          const chosenSt = openStForPath(chosen.pathObj.id, "half1", targetDept, dateStr, shiftType);
          if (chosenSt) {
            setStationAssignment(ctx, chosenSt.id, "half1", { 
              login: assoc.login, 
              name: assoc.name, 
              badge: assoc.badge, 
              path: chosen.path, 
              roleType: chosen.roleType, 
              assignedAt: Date.now(), 
              method: "SCAN", 
              dept: targetDept, 
              half: "half1" 
            });
            setBadgeAssignment(ctx, assoc.badge, "half1", chosenSt.id);
            h1 = { 
              path: chosen.path, 
              station: chosenSt, 
              score: chosen.score, 
              lc: chosen.lc, 
              roleType: chosen.roleType, 
              rotationHours: chosen.rotationHours, 
              breakdown: chosen.breakdown, 
              allScores: [] 
            };
          } else {
            h1 = { path: "SEE ADMIN", station: null, score: 0, lc: 0, roleType: null, rotationHours: 0, breakdown: [], allScores: [], seeAdminReason: "No station available." };
          }
        } else {
          h1 = { path: "SEE ADMIN", station: null, score: 0, lc: 0, roleType: null, rotationHours: 0, breakdown: [], allScores: [], seeAdminReason: "No first half stations open." };
        }
      }

      if (needH2) {
        if (isOpenH2) {
          const h2St = openStForPath(chosen.pathObj.id, "half2", targetDept, dateStr, shiftType);
          if (h2St) {
            setStationAssignment(ctx, h2St.id, "half2", { 
              login: assoc.login, 
              name: assoc.name, 
              badge: assoc.badge, 
              path: chosen.path, 
              roleType: chosen.roleType, 
              assignedAt: Date.now(), 
              method: "SCAN", 
              dept: targetDept, 
              half: "half2" 
            });
            setBadgeAssignment(ctx, assoc.badge, "half2", h2St.id);
            h2 = { 
              path: chosen.path, 
              station: h2St, 
              score: chosen.score, 
              lc: chosen.lc, 
              roleType: chosen.roleType, 
              rotationHours: chosen.rotationHours, 
              breakdown: [], 
              allScores: [] 
            };
          } else {
            h2 = { path: "SEE ADMIN", station: null, score: 0, lc: 0, roleType: null, rotationHours: 0, breakdown: [], allScores: [], seeAdminReason: "No station available." };
          }
        } else {
          h2 = { path: "SEE ADMIN", station: null, score: 0, lc: 0, roleType: null, rotationHours: 0, breakdown: [], allScores: [], seeAdminReason: "No second half stations open." };
        }
      }
    } else {
      if (needH1) {
        h1 = { path: "SEE ADMIN", station: null, score: 0, lc: 0, roleType: null, rotationHours: 0, breakdown: [], allScores: [], seeAdminReason: "All structures full." };
      }
      if (needH2) {
        h2 = { path: "SEE ADMIN", station: null, score: 0, lc: 0, roleType: null, rotationHours: 0, breakdown: [], allScores: [], seeAdminReason: "All structures full." };
      }
    }

    if (!shiftAssignments[sKey]) shiftAssignments[sKey] = {};
    shiftAssignments[sKey][assoc.badge] = { date: dateStr, half1: h1, half2: h2, dept: targetDept, shiftType };
    savePlacementsRaw();

    if (isCrossDept) incrementCrossDept(contextKey);

    return {
      associate: assoc,
      path: h1?.path || "SEE ADMIN",
      station: h1?.station,
      score: h1?.score || 0,
      lc: h1?.lc || 0,
      roleType: h1?.roleType,
      rotationHours: h1?.rotationHours,
      breakdown: h1?.breakdown || [],
      allScores: [],
      method: (assignedStIdH1 || assignedStIdH2) ? "RECALL" : "AUTO",
      isRecall: !!(assignedStIdH1 || assignedStIdH2),
      half,
      half1: h1,
      half2: h2,
      consec3: consec3Indirect(assoc.badge, targetDept),
      dept: targetDept,
      assignedDept: targetDept
    };
  };

  const refreshFloorData = async () => {
    try {
      const linesRes = await fetch(`${API}/lines`).then(r => r.json());
      const stationsRes = await fetch(`${API}/stations`).then(r => r.json());
      if (Array.isArray(linesRes) && linesRes.length) {
        setFloorLines(linesRes);
      }
      if (Array.isArray(stationsRes) && stationsRes.length) {
        setFloorStations(stationsRes);
      }
    } catch (err) {
      console.error("Failed to refresh floor data:", err);
    }
  };

  const loadPlacementsFromServer = async () => {
    try {
      const res = await fetch(`${API}/placements`).then(r => r.json());
      if (res) {
        Object.keys(contextStations).forEach(k => delete contextStations[k]);
        Object.keys(contextBadges).forEach(k => delete contextBadges[k]);
        Object.keys(shiftAssignments).forEach(k => delete shiftAssignments[k]);

        Object.assign(contextStations, res.contextStations || {});
        Object.assign(contextBadges, res.contextBadges || {});
        Object.assign(shiftAssignments, res.shiftAssignments || {});
        
        // Trigger state update
        setLog(p => [...p]);
      }
    } catch (e) {
      console.error("Failed to load placements:", e);
    }
  };

  useEffect(() => {
    refreshFloorData();
    loadPlacementsFromServer();
  }, [tab]);
  const [clock, setClock] = useState(fmtTime());
  const [shiftType, setShiftType] = useState("DAY");
  const [staffDate, setStaffDate] = useState(new Date());
  const [dept, setDept] = useState("INBOUND");
  const [log, setLog] = useState<any[]>([]);
  const [auditEvents, setAuditEvents] = useState<any[]>([]);

  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null);
  const [activeAdmin, setActiveAdmin] = useState<any>(null);

  const [laborShareEnabled, setLaborShareEnabled] = useState(false);
  const [laborShareCount, setLaborShareCount] = useState(0);
  const [crossDeptUsage, setCrossDeptUsage] = useState<any>({});

  const incrementCrossDept = (key: string) => {
    setCrossDeptUsage((prev: any) => ({ ...prev, [key]: (prev[key] || 0) + 1 }));
  };

  const getCrossDeptUsed = (key: string) => crossDeptUsage[key] || 0;

  useEffect(() => {
    const t = setInterval(() => setClock(fmtTime()), 5000);
    return () => clearInterval(t);
  }, []);

  useEffect(() => {
    const session = localStorage.getItem("ct_admin_session");
    if (session) {
      try {
        const parsed = JSON.parse(session);
        if (parsed.expires && parsed.expires > Date.now()) {
          setIsAuthenticated(true);
          setActiveAdmin(parsed);
        } else {
          localStorage.removeItem("ct_admin_session");
          setIsAuthenticated(false);
        }
      } catch {
        setIsAuthenticated(false);
      }
    } else {
      setIsAuthenticated(false);
    }
  }, []);

  const refreshAssociates = async () => {
    try {
      const data = await fetch(`${API}/associates`).then(r => r.json());
      if (Array.isArray(data) && data.length) {
        mockAssocs = data;
      }
    } catch {}
  };

  useEffect(() => {
    refreshAssociates();
  }, [tab]);

  const resetShift = async () => {
    if (!window.confirm("do you want resett the floor of today.")) return;
    try {
      await fetch(`${API}/reset-shift`, { method: "POST" });
      const linesRes = await fetch(`${API}/lines`).then(r => r.json());
      const stationsRes = await fetch(`${API}/stations`).then(r => r.json());
      if (Array.isArray(linesRes) && linesRes.length) {
        setFloorLines(linesRes);
      }
      if (Array.isArray(stationsRes) && stationsRes.length) {
        setFloorStations(stationsRes);
      }
    } catch {}
    
    // Clear all client assignments
    Object.keys(contextStations).forEach(k => delete contextStations[k]);
    Object.keys(contextBadges).forEach(k => delete contextBadges[k]);
    Object.keys(shiftAssignments).forEach(k => delete shiftAssignments[k]);
    savePlacementsRaw();

    setLog([]);
    setAuditEvents([]);
    alert("Floor coordinates successfully reset.");
  };

  const handleAuthenticate = (admin: any) => {
    setIsAuthenticated(true);
    setActiveAdmin(admin);
  };

  const handleSignOut = () => {
    localStorage.removeItem("ct_admin_session");
    setIsAuthenticated(false);
    setActiveAdmin(null);
  };

  const onPlaceAudit = (action: string, badge: string, name: string, station: string, path: string, dept: string, shift: string, date: string) => {
    const who = activeAdmin ? `${activeAdmin.name} (${activeAdmin.role})` : "Automated Flow";
    const auditObj = { who, badge, name, station, path, action, dept, shiftType: shift, date, ts: Date.now() };
    setAuditEvents(curr => [auditObj, ...curr]);
  };

  if (isAuthenticated === false) {
    return <AdminGate onAuthenticate={handleAuthenticate} apiUrl={API} />;
  }

  if (isAuthenticated === null) {
    return (
      <div className="flex bg-[#F9FAFB] min-h-screen items-center justify-center">
        <div className="w-6 h-6 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
      </div>
    );
  }

  const TABS = [
    { id: "kiosk", label: "KIOSK", icon: "🔖", subtitle: "Automated scan console" },
    { id: "dashboard", label: "DASHBOARD", icon: "📊", subtitle: "Operational overview feeds" },
    { id: "map", label: "FLOOR MAP", icon: "🗺️", subtitle: "Manage lines stations halves" },
    { id: "perms", label: "PERMISSIONS", icon: "🔐", subtitle: "Learning Curve competencies" },
    { id: "assocs", label: "ASSOCIATES", icon: "👥", subtitle: "Registered personnel database" },
    { id: "history", label: "HISTORY", icon: "📋", subtitle: "History audit registry logs" },
    { id: "search", label: "SEARCH", icon: "🔍", subtitle: "Employee profile lookups" },
    { id: "report", label: "REPORT", icon: "📥", subtitle: "Placements report downloads" },
    { id: "perf", label: "PERFORMANCE", icon: "📈", subtitle: "Target scanning velocity" },
    { id: "alerts", label: "ALERTS", icon: "🚨", subtitle: "Andon alarm triggers" },
    { id: "leaderboard", label: "LEADERBOARD", icon: "🏆", subtitle: "Operator monthly high score" },
    { id: "settings", label: "SETTINGS", icon: "⚙️", subtitle: "Priorities weights toggles" }
  ];

  const activeTabDetails = TABS.find(t => t.id === tab);

  return (
    <div className="flex h-screen w-full bg-[#F9FAFB] text-[#111827] font-sans overflow-hidden">
      {/* Dynamic Navigation Sidebar */}
      <div className="w-64 bg-white border-r border-gray-250 flex flex-col h-full shrink-0">
        <div className="p-6 border-b border-gray-200">
          <div className="w-9 h-9 rounded-xl bg-indigo-600 text-white flex items-center justify-center font-bold text-sm tracking-wider mb-2">
            CT
          </div>
          <h1 className="text-base font-extrabold tracking-tight text-gray-900 uppercase">Control Tower</h1>
          <p className="text-[10px] text-gray-400 font-mono tracking-widest mt-0.5">TEN1 console manager</p>
        </div>

        <nav className="flex-1 p-4 space-y-1 bg-white overflow-y-auto">
          {TABS.map(t => {
            const isSel = tab === t.id;
            return (
              <button
                key={t.id}
                onClick={() => setTab(t.id)}
                className={`w-full flex items-center gap-3 px-3 py-2.5 text-xs font-bold uppercase tracking-wider rounded-xl text-left border-none cursor-pointer transition-all ${
                  isSel ? "bg-indigo-50 text-indigo-750 font-extrabold shadow-sm" : "text-gray-500 hover:text-gray-900 hover:bg-gray-50/50"
                }`}
              >
                <span>{t.icon}</span>
                <span>{t.label}</span>
              </button>
            );
          })}
        </nav>

        {activeAdmin && (
          <div className="p-4 border-t border-gray-150 flex flex-col gap-2 bg-[#FAFBFD]/30">
            <div className="flex items-center gap-2">
              <div className="w-7 h-7 rounded-full bg-emerald-500 text-white text-[10px] font-bold flex items-center justify-center uppercase font-mono">
                {activeAdmin.name.charAt(0)}
              </div>
              <div className="flex-1 min-w-0">
                <div className="text-[11px] font-bold text-gray-900 truncate">{activeAdmin.name}</div>
                <div className="text-[9px] text-gray-400 font-mono mt-0.5 uppercase tracking-wider">{activeAdmin.role}</div>
              </div>
            </div>
            <button onClick={handleSignOut} className="w-full py-1.5 bg-[#FEF2F2] hover:bg-[#FEE2E2] border border-[#FEE2E2] text-[#DC2626] rounded-xl text-[10px] font-bold font-mono uppercase tracking-widest cursor-pointer mt-1">
              🚪 Sign out
            </button>
          </div>
        )}
      </div>

      {/* Main Workspace Frame */}
      <div className="flex-1 flex flex-col h-full min-w-0 overflow-hidden">
        {/* Clean minimal navbar header */}
        <header className="h-20 bg-white border-b border-gray-200 flex items-center justify-between px-8 shrink-0">
          <div>
            <h2 className="text-base font-extrabold tracking-tight text-gray-900 flex items-center gap-1.5">
              <span>{activeTabDetails?.icon}</span>
              <span>{activeTabDetails?.label}</span>
            </h2>
            <p className="text-xs text-gray-400 font-medium">
              {activeTabDetails?.subtitle}
            </p>
          </div>

          <div className="flex items-center gap-3">
            {/* Dept mode selectors */}
            <div className="flex bg-gray-100 p-1 rounded-xl border border-gray-250 overflow-hidden font-mono text-[9px] font-bold">
              {["INBOUND", "OUTBOUND"].map(d => (
                <button
                  key={d}
                  onClick={() => setDept(d)}
                  className={`px-3 py-1.5 rounded-lg border-none cursor-pointer transition-colors ${
                    dept === d ? "bg-white text-indigo-700 shadow-sm" : "text-gray-500 hover:text-gray-900"
                  }`}
                >
                  {d}
                </button>
              ))}
            </div>

            {/* Shift daytime pills */}
            <div className="flex bg-gray-100 p-1 rounded-xl border border-gray-250 overflow-hidden font-mono text-[9px] font-bold">
              {[
                { v: "DAY", l: "☀ Day" },
                { v: "NIGHT", l: "🌙 Night" }
              ].map(s => (
                <button
                  key={s.v}
                  onClick={() => setShiftType(s.v)}
                  className={`px-3 py-1.5 rounded-lg border-none cursor-pointer transition-colors ${
                    shiftType === s.v ? "bg-white text-indigo-700 shadow-sm" : "text-gray-500 hover:text-gray-900"
                  }`}
                >
                  {s.l}
                </button>
              ))}
            </div>

            {/* Calendar Date Picker */}
            <div className="flex bg-gray-100 p-1 rounded-xl border border-gray-250 items-center font-mono text-[9px] font-bold">
              <span className="pl-1.5 pr-1.5 text-gray-400">📅</span>
              <input
                type="date"
                value={staffDate instanceof Date ? staffDate.toISOString().split("T")[0] : staffDate}
                onChange={e => {
                  if (e.target.value) {
                    setStaffDate(new Date(e.target.value + "T00:00:00"));
                  }
                }}
                className="bg-transparent border-none text-[9px] font-extrabold font-mono text-gray-700 outline-none cursor-pointer pr-1"
              />
            </div>

            {/* Dynamic Active Shift Schedule Badge */}
            {(() => {
              const info = getShiftInfoText(staffDate);
              const activeLabel = shiftType === "DAY" ? info.dayShift : info.nightShift;
              return (
                <div className={`px-3 py-1 rounded-xl border font-mono text-[9px] font-extrabold flex flex-col justify-center select-none shadow-3xs transition-all ${
                  info.overlapping ? "bg-amber-50 border-amber-200 text-amber-800" : "bg-indigo-50 border-indigo-205 text-indigo-750"
                }`}>
                  <span className="text-[7.5px] text-gray-400 font-extrabold uppercase leading-tight">ACTIVE DAILY SHIFT:</span>
                  <span className="leading-normal">{activeLabel}</span>
                </div>
              );
            })()}

            {/* Dynamic clock indicator */}
            <div className="font-mono text-[10px] font-bold text-gray-400 bg-gray-50 border border-gray-150 py-1.5 px-3.5 rounded-xl shadow-3xs flex items-center gap-1.5">
              <span className="w-1.5 h-1.5 rounded-full bg-indigo-600 animate-ping"></span>
              <span>{clock}</span>
            </div>

            <button onClick={resetShift} className="px-3 py-1.5 bg-red-50 hover:bg-red-100 text-red-650 rounded-xl text-[10px] font-bold font-mono border border-red-150 uppercase tracking-widest cursor-pointer shadow-3xs transition-colors">
              Reset Session
            </button>
          </div>
        </header>

        {/* Scrollable container frame */}
        <main className="p-8 flex-1 overflow-y-auto space-y-6">
          <div className="flex-1">
            {tab === "kiosk" && (
              <Kiosk
                onAssign={e => setLog(p => [...p, e])}
                shiftType={shiftType}
                staffDate={staffDate}
                laborShareEnabled={laborShareEnabled}
                laborShareCount={laborShareCount}
                crossDeptUsage={crossDeptUsage}
                incrementCrossDept={incrementCrossDept}
                getCrossDeptUsed={getCrossDeptUsed}
                mockAssocs={mockAssocs}
                floorPaths={floorPaths}
                floorLines={floorLines}
                floorStations={floorStations}
                getStationAssignment={getStationAssignment}
                setStationAssignment={setStationAssignment}
                setBadgeAssignment={setBadgeAssignment}
                consec3Indirect={consec3Indirect}
                runScanWithLaborShare={runScanWithLaborShare}
              />
            )}
            {tab === "dashboard" && (
              <Dashboard
                shiftType={shiftType}
                staffDate={staffDate}
                dept={dept}
                floorPaths={floorPaths}
                floorLines={floorLines}
                floorStations={floorStations}
                getStationAssignment={getStationAssignment}
                getBadgeAssignment={getBadgeAssignment}
                SA={SA}
                shiftAssignments={shiftAssignments}
                mockAssocs={mockAssocs}
              />
            )}
            {tab === "map" && (
              <FloorMap
                dept={dept}
                staffDate={staffDate}
                shiftType={shiftType}
                mockAssocs={mockAssocs}
                floorPaths={floorPaths}
                floorLines={floorLines}
                floorStations={floorStations}
                setFloorLines={setFloorLines}
                setFloorStations={setFloorStations}
                setFloorPaths={setFloorPaths}
                refreshAssociates={refreshAssociates}
                getStationAssignment={getStationAssignment}
                setStationAssignment={setStationAssignment}
                setBadgeAssignment={setBadgeAssignment}
                getBadgeAssignment={getBadgeAssignment}
                clearStationAssignment={clearStationAssignment}
                SA={SA}
                LA={LA}
                onPlaceAudit={onPlaceAudit}
                laborShareEnabled={laborShareEnabled}
                laborShareCount={laborShareCount}
                getCrossDeptUsed={getCrossDeptUsed}
                incrementCrossDept={incrementCrossDept}
              />
            )}
            {tab === "perms" && (
              <Permissions
                dept={dept}
                mockAssocs={mockAssocs}
                floorPaths={floorPaths}
                refreshAssociates={refreshAssociates}
              />
            )}
            {tab === "assocs" && (
              <Associates
                dept={dept}
                mockAssocs={mockAssocs}
                refreshAssociates={refreshAssociates}
              />
            )}
            {tab === "history" && (
              <AssignHistory
                dept={dept}
                mockAssocs={mockAssocs}
              />
            )}
            {tab === "search" && (
              <SearchLookup
                mockAssocs={mockAssocs}
              />
            )}
            {tab === "report" && (
              <Report
                dept={dept}
                staffDate={staffDate}
                shiftType={shiftType}
                floorStations={floorStations}
                floorLines={floorLines}
                floorPaths={floorPaths}
                getStationAssignment={getStationAssignment}
                auditEvents={auditEvents}
              />
            )}
            {tab === "perf" && <Performance />}
            {tab === "alerts" && <Alerts />}
            {tab === "leaderboard" && <Leaderboard />}
            {tab === "settings" && (
              <Settings
                apiUrl={API}
                userRole={activeAdmin?.role}
                onAdminChange={setActiveAdmin}
                mockAssocs={mockAssocs}
                floorPaths={floorPaths}
                refreshAssociates={refreshAssociates}
              />
            )}
          </div>
        </main>
      </div>
    </div>
  );
}
