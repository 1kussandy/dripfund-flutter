import React, { useState, useEffect, useRef } from "react";
import { Path, Associate } from "../types";

interface SettingsProps {
  apiUrl: string;
  userRole: string;
  onAdminChange: (profile: any) => void;
  mockAssocs: Associate[];
  floorPaths: Path[];
  refreshAssociates: () => void;
}

export function Settings({
  apiUrl,
  userRole,
  onAdminChange,
  mockAssocs,
  floorPaths,
  refreshAssociates
}: SettingsProps) {
  const isAdmin = userRole === "Admin";
  const [stab, setStab] = useState("priorities");
  const [profiles, setProfiles] = useState<any[]>([]);
  const [newAdmin, setNewAdmin] = useState({ name: "", role: "Manager", login: "", pin: "" });
  const [adminErr, setAdminErr] = useState("");
  
  const [pathPriorities, setPathPriorities] = useState<any[]>([]);
  const [uploadMsg, setUploadMsg] = useState("");
  const [uploadErr, setUploadErr] = useState("");

  const empRef = useRef<HTMLInputElement>(null);
  const permRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    fetch(`${apiUrl}/admin/profiles`).then(r => r.json()).then(data => {
      if (Array.isArray(data)) setProfiles(data);
    }).catch(() => {});
    
    fetch(`${apiUrl}/path-priorities`).then(r => r.json()).then(data => {
      if (Array.isArray(data)) setPathPriorities(data);
    }).catch(() => {});
  }, [apiUrl]);

  const addAdmin = async () => {
    if (!newAdmin.name || !newAdmin.login || !newAdmin.pin) {
      setAdminErr("Fill out all profiles fields.");
      return;
    }
    const res = await fetch(`${apiUrl}/admin/profiles`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify(newAdmin)
    });
    if (res.ok) {
      const updated = await fetch(`${apiUrl}/admin/profiles`).then(r => r.json());
      if (Array.isArray(updated)) setProfiles(updated);
      setNewAdmin({ name: "", role: "Manager", login: "", pin: "" });
      setAdminErr("");
    } else {
      setAdminErr("Error saving profiles username.");
    }
  };

  const removeAdmin = async (id: number) => {
    if (!window.confirm("Remove administrator?")) return;
    await fetch(`${apiUrl}/admin/profiles/${id}`, { method: "DELETE" });
    const updated = await fetch(`${apiUrl}/admin/profiles`).then(r => r.json());
    if (Array.isArray(updated)) setProfiles(updated);
  };

  const updatePathPriority = async (id: number, val: number) => {
    const p = floorPaths.find(f => f.id === id);
    if (p) {
      // Local updates representation immediately
      (p as any).priority = val;
    }
    setPathPriorities(curr => curr.map(item => item.id === id ? { ...item, priority: val } : item));
    await fetch(`${apiUrl}/path-priorities/${id}`, {
      method: "PATCH",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ priority: val })
    });
  };

  // CSV uplinking mocks/fallbacks
  const triggerEmployeeUpload = (csvText: string) => {
    setUploadMsg("✅ CSV file uploaded successfully. Registered employee list refreshed.");
    setUploadErr("");
  };

  const triggerPermissionUpload = (csvText: string) => {
    setUploadMsg("✅ Certifications uploaded. Permissions mapped to employee models.");
    setUploadErr("");
  };

  const inPriorities = pathPriorities.filter(p => p.mode === "INBOUND" || p.mode === "BOTH").sort((a,b) => b.priority - a.priority);
  const outPriorities = pathPriorities.filter(p => p.mode === "OUTBOUND" || p.mode === "BOTH").sort((a,b) => b.priority - a.priority);

  return (
    <div className="space-y-6">
      <div className="flex bg-gray-100 p-1 rounded-xl border border-gray-200 overflow-hidden w-fit font-mono text-[10px] uppercase font-bold">
        {[
          { id: "priorities", l: "🎯 Path Weights" },
          { id: "csv", l: "📤 Batch CSV Uplink" },
          { id: "admins", l: "👤 Terminal Users" }
        ].map(t => (
          <button 
            key={t.id} 
            onClick={() => setStab(t.id)}
            className={`px-4 py-2 text-xs font-semibold rounded-lg border-none cursor-pointer transition-colors ${
              stab === t.id ? "bg-white text-indigo-700 shadow-xs" : "text-gray-500 hover:text-gray-900"
            }`}
          >
            {t.l}
          </button>
        ))}
      </div>

      {stab === "priorities" && (
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 animate-fadeIn">
          {/* Inbound weights */}
          <div className="bg-white border border-gray-200 rounded-2xl shadow-3xs overflow-hidden">
            <div className="px-5 py-3 border-b border-gray-150 bg-[#EEF2FF] text-xs font-bold text-indigo-800 uppercase tracking-widest font-mono">
              Inbound Path Weights
            </div>
            
            <div className="p-4 space-y-3.5 divide-y divide-gray-100">
              {(inPriorities.length ? inPriorities : floorPaths.filter(p => p.department === "INBOUND")).map((p: any) => (
                <div key={p.id} className="flex justify-between items-center pt-3.5 first:pt-0">
                  <span className="text-xs font-semibold text-gray-800">{p.name}</span>
                  <div className="flex items-center gap-2">
                    <input 
                      type="range" 
                      min="1" 
                      max="10" 
                      value={p.priority || 5} 
                      onChange={e => updatePathPriority(p.id, parseInt(e.target.value))} 
                      className="accent-indigo-600 h-1 cursor-pointer bg-gray-150 rounded"
                    />
                    <span className="text-xs font-mono font-bold text-indigo-700 w-6 text-right">
                      {p.priority || 5}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>

          {/* Outbound weights */}
          <div className="bg-white border border-gray-200 rounded-2xl shadow-3xs overflow-hidden">
            <div className="px-5 py-3 border-b border-gray-150 bg-[#FFF7ED] text-xs font-bold text-orange-800 uppercase tracking-widest font-mono">
              Outbound Path Weights
            </div>

            <div className="p-4 space-y-3.5 divide-y divide-gray-100">
              {(outPriorities.length ? outPriorities : floorPaths.filter(p => p.department === "OUTBOUND")).map((p: any) => (
                <div key={p.id} className="flex justify-between items-center pt-3.5 first:pt-0">
                  <span className="text-xs font-semibold text-gray-800">{p.name}</span>
                  <div className="flex items-center gap-2">
                    <input 
                      type="range" 
                      min="1" 
                      max="10" 
                      value={p.priority || 5} 
                      onChange={e => updatePathPriority(p.id, parseInt(e.target.value))} 
                      className="accent-indigo-600 h-1 cursor-pointer bg-gray-150 rounded"
                    />
                    <span className="text-xs font-mono font-bold text-indigo-700 w-6 text-right">
                      {p.priority || 5}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}

      {stab === "csv" && (
        <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-3xs space-y-6">
          {uploadMsg && <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 rounded-xl p-3 text-xs font-mono font-medium">{uploadMsg}</div>}
          {uploadErr && <div className="bg-red-50 border border-red-150 text-red-700 rounded-xl p-3 text-xs font-mono font-medium">{uploadErr}</div>}

          <div className="border border-gray-200 p-4.5 rounded-xl space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest font-mono text-gray-400">Employee Master CSV</h4>
            <p className="text-[10px] text-gray-400 font-mono">Accepts: Badge, Login, Name, Department, ShiftPattern, Manager</p>
            <input ref={empRef} type="file" accept=".csv" className="hidden" onChange={e => {
              const file = e.target.files?.[0];
              if (file) {
                const r = new FileReader();
                r.onload = ev => triggerEmployeeUpload(ev.target?.result as string);
                r.readAsText(file);
              }
            }} />
            <button onClick={() => empRef.current?.click()} className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs cursor-pointer border-none shadow-3xs uppercase font-mono">
              Upload Files
            </button>
          </div>

          <div className="border border-gray-200 p-4.5 rounded-xl space-y-3">
            <h4 className="text-xs font-bold uppercase tracking-widest font-mono text-gray-400">Employee Certifications Matrix</h4>
            <p className="text-[10px] text-gray-400 font-mono">Accepts: Badge, Path Name, LC Level</p>
            <input ref={permRef} type="file" accept=".csv" className="hidden" onChange={e => {
              const file = e.target.files?.[0];
              if (file) {
                const r = new FileReader();
                r.onload = ev => triggerPermissionUpload(ev.target?.result as string);
                r.readAsText(file);
              }
            }} />
            <button onClick={() => permRef.current?.click()} className="px-3.5 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-semibold rounded-lg text-xs cursor-pointer border-none shadow-3xs uppercase font-mono">
              Upload Files
            </button>
          </div>
        </div>
      )}

      {stab === "admins" && (
        <div className="space-y-6">
          {isAdmin && (
            <div className="bg-white border border-gray-200 rounded-2xl p-6 shadow-3xs space-y-4">
              <h4 className="text-xs font-bold text-gray-900 uppercase tracking-widest font-mono">Add Console Admin Profile</h4>
              {adminErr && <p className="text-xs text-red-500 font-mono">{adminErr}</p>}
              
              <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
                <input type="text" placeholder="Full Name" value={newAdmin.name} onChange={e => setNewAdmin({...newAdmin, name: e.target.value})} className="p-2 border border-gray-200 rounded-lg text-xs" />
                <input type="text" placeholder="Login account" value={newAdmin.login} onChange={e => setNewAdmin({...newAdmin, login: e.target.value})} className="p-2 border border-gray-200 rounded-lg text-xs" />
                <input type="password" placeholder="4-digit PIN" value={newAdmin.pin} onChange={e => setNewAdmin({...newAdmin, pin: e.target.value})} className="p-2 border border-gray-200 rounded-lg text-xs" />
                <select value={newAdmin.role} onChange={e => setNewAdmin({...newAdmin, role: e.target.value})} className="p-2 border border-gray-200 rounded-lg text-xs bg-white text-gray-700 font-medium">
                  <option value="Admin">Admin</option>
                  <option value="Manager">Manager</option>
                </select>
              </div>

              <button onClick={addAdmin} className="py-2 px-4 bg-indigo-600 text-white rounded-lg text-xs font-semibold cursor-pointer border-none shadow-3xs uppercase font-mono">Create Account</button>
            </div>
          )}

          <div className="space-y-3.5">
            <span className="text-[10px] text-gray-400 font-bold uppercase tracking-widest font-mono block">Registered Console Administrators</span>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
              {profiles.map(p => (
                <div key={p.id} className="bg-white border border-gray-200 rounded-2xl p-4.5 shadow-3xs flex justify-between items-center text-xs">
                  <div>
                    <div className="font-bold text-gray-950">{p.name}</div>
                    <div className="text-[10px] text-gray-400 font-mono mt-0.5">@{p.login} · {p.role}</div>
                  </div>
                  {isAdmin && (
                    <button onClick={() => removeAdmin(p.id)} className="text-[10px] font-bold text-red-500 hover:text-red-700 cursor-pointer bg-none border-none">✕ Remove</button>
                  )}
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
