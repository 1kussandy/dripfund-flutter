import React, { useState, useEffect } from "react";
import { Path, Line, Station, Associate } from "../types";

interface FloorMapProps {
  dept: string;
  staffDate: Date | string;
  shiftType: string;
  mockAssocs: Associate[];
  floorPaths: Path[];
  floorLines: Line[];
  floorStations: Station[];
  setFloorLines: React.Dispatch<React.SetStateAction<Line[]>>;
  setFloorStations: React.Dispatch<React.SetStateAction<Station[]>>;
  setFloorPaths: React.Dispatch<React.SetStateAction<Path[]>>;
  refreshAssociates: () => void;
  getStationAssignment: (ctx: string, sid: number, half: string) => any;
  setStationAssignment: (ctx: string, sid: number, half: string, assignment: any) => void;
  setBadgeAssignment: (ctx: string, badge: string, half: string, sid: number) => void;
  getBadgeAssignment: (ctx: string, badge: string, half: string) => any;
  clearStationAssignment: (ctx: string, sid: number, half: string) => void;
  SA: (sid: number, half: string) => boolean;
  LA: (lid: number, half: string) => boolean;
  onPlaceAudit: (action: string, badge: string, name: string, station: string, path: string, dept: string, shift: string, date: string) => void;
  laborShareEnabled: boolean;
  laborShareCount: number;
  getCrossDeptUsed: (key: string) => number;
  incrementCrossDept: (key: string) => void;
}

export function FloorMap({
  dept,
  staffDate,
  shiftType,
  mockAssocs,
  floorPaths,
  floorLines,
  floorStations,
  setFloorLines,
  setFloorStations,
  setFloorPaths,
  refreshAssociates,
  getStationAssignment,
  setStationAssignment,
  setBadgeAssignment,
  getBadgeAssignment,
  clearStationAssignment,
  SA,
  LA,
  onPlaceAudit,
  laborShareEnabled,
  laborShareCount,
  getCrossDeptUsed,
  incrementCrossDept
}: FloorMapProps) {
  const [, fu] = useState(0);
  const tick = () => fu(n => n + 1);

  const [selectedHalf, setSelectedHalf] = useState<"half1" | "half2">("half1");

  const [expPaths, setExpPaths] = useState<Set<number>>(new Set([1]));
  const [expLines, setExpLines] = useState<Set<number>>(new Set());

  // Add items modal states
  const [addPathM, setAddPathM] = useState(false);
  const [addLineM, setAddLineM] = useState(false);
  const [addStM, setAddStM] = useState(false);

  // Manual assign states
  const [manModal, setManModal] = useState<any>(null); // { sid, stName, pathName, half }
  const [manBadge, setManBadge] = useState("");
  const [manMsg, setManMsg] = useState("");

  const [nPath, setNPath] = useState({ name: "", role_type: "DIRECT" as "DIRECT" | "INDIRECT" });
  const [nLine, setNLine] = useState({ name: "", path_id: "" });
  const [nSt, setNSt] = useState({ name: "", side: "ODD" as "ODD" | "EVEN", line_id: "" });

  const dateStr = staffDate instanceof Date ? staffDate.toISOString().split("T")[0] : staffDate;
  const ctx = `${dateStr}|${shiftType}|${dept}`;

  const GA = (sid: number, half: string) => {
    return getStationAssignment(ctx, sid, half) || null;
  };

  const clrSt = (sid: number, half: string) => {
    const asn = GA(sid, half);
    if (asn) {
      onPlaceAudit("CLEAR", asn.badge, asn.name, floorStations.find(s => s.id === sid)?.name || "", asn.path, dept, shiftType, dateStr);
      clearStationAssignment(ctx, sid, half);
      
      // Remove badge reference from tracking
      const sessionFile = localStorage.getItem(`ct_badge_${ctx}`);
      if (sessionFile) {
        try {
          const parsed = JSON.parse(sessionFile);
          if (parsed[asn.badge]) delete parsed[asn.badge][half];
          localStorage.setItem(`ct_badge_${ctx}`, JSON.stringify(parsed));
        } catch {}
      }
    }
    tick();
  };

  const doAssign = () => {
    if (!manBadge.trim()) return;
    const assoc = mockAssocs.find(a => a.badge === manBadge.trim() || a.login === manBadge.trim().toLowerCase() || a.name.toLowerCase().includes(manBadge.trim().toLowerCase()));
    if (!assoc) {
      setManMsg("Associate not found in database.");
      return;
    }

    const stationObj = floorStations.find(s => s.id === manModal.sid);
    const lineObj = floorLines.find(l => l.id === stationObj?.line_id);
    const pathObj = floorPaths.find(p => p.id === lineObj?.path_id);
    
    // Cross dept checks
    const isCrossDept = pathObj?.department && assoc.operation_mode !== "BOTH" && assoc.operation_mode !== pathObj.department;
    if (isCrossDept && !laborShareEnabled) {
      setManMsg(`Labor Share disabled. Cannot assign ${assoc.name} to ${pathObj?.department} station.`);
      return;
    }

    const usageKey = `live|${dept}|${dateStr}|${shiftType}`;
    const used = getCrossDeptUsed(usageKey);
    if (isCrossDept && laborShareCount > 0 && used >= laborShareCount) {
      setManMsg(`Labor share limit reached (${used}/${laborShareCount}).`);
      return;
    }

    // Set placement inside specific half
    setStationAssignment(ctx, manModal.sid, manModal.half, {
      login: assoc.login,
      name: assoc.name,
      badge: assoc.badge,
      path: manModal.pathName,
      roleType: "MANUAL",
      assignedAt: Date.now(),
      method: "MANUAL",
      dept,
      half: manModal.half
    });
    setBadgeAssignment(ctx, assoc.badge, manModal.half, manModal.sid);

    if (isCrossDept) incrementCrossDept(usageKey);

    onPlaceAudit("ASSIGN", assoc.badge, assoc.name, manModal.stName, manModal.pathName, dept, shiftType, dateStr);
    setManMsg(`${assoc.name} successfully placed for ${manModal.half === "half1" ? "1ST" : "2ND"} half!`);
    
    tick();
    setTimeout(() => {
      setManModal(null);
      setManBadge("");
      setManMsg("");
    }, 1200);
  };

  const togPath = (pid: number) => {
    const p = floorPaths.find(x => x.id === pid);
    if (p) p.active = !p.active;
    tick();
  };

  const togLineHalf = async (lid: number, half: "half1" | "half2") => {
    const l = floorLines.find(x => x.id === lid);
    if (!l) return;

    let newValue: boolean;
    if (half === "half1") {
      newValue = l.active_half1 === false ? true : false;
    } else {
      newValue = l.active_half2 === false ? true : false;
    }

    // 1. Update line and child stations in local React state
    setFloorLines(prev => prev.map(item => {
      if (item.id === lid) {
        return {
          ...item,
          [half === "half1" ? "active_half1" : "active_half2"]: newValue
        };
      }
      return item;
    }));

    setFloorStations(prev => prev.map(item => {
      if (item.line_id === lid) {
        return {
          ...item,
          [half === "half1" ? "active_half1" : "active_half2"]: newValue
        };
      }
      return item;
    }));

    // If turned off, clear all active assignments for this half on this line
    if (newValue === false) {
      floorStations.forEach(st => {
        if (st.line_id === lid) {
          clearStationAssignment(ctx, st.id, half);
        }
      });
      tick();
    }

    // 2. Persist to API
    const body: any = {};
    if (half === "half1") {
      body.active_half1 = newValue;
    } else {
      body.active_half2 = newValue;
    }

    try {
      await fetch(`/api/lines/${lid}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(body)
      });
    } catch (err) {
      console.error("Failed to patch line:", err);
    }
  };

  const togStActive = async (sid: number) => {
    const s = floorStations.find(x => x.id === sid);
    if (!s) return;

    const isCurrentlyActive = s.active_half1 !== false || s.active_half2 !== false;
    const newValue = !isCurrentlyActive;

    // 1. Update local React state for both halves
    setFloorStations(prev => prev.map(item => {
      if (item.id === sid) {
        return {
          ...item,
          active_half1: newValue,
          active_half2: newValue,
          status: newValue ? "OPERATIONAL" : "DISABLED"
        };
      }
      return item;
    }));

    // If station turned off, clear assignments for both halves
    if (newValue === false) {
      clearStationAssignment(ctx, sid, "half1");
      clearStationAssignment(ctx, sid, "half2");
      tick();
    }

    // 2. Persist to API
    try {
      await fetch(`/api/stations/${sid}`, {
        method: "PATCH",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          active_half1: newValue,
          active_half2: newValue
        })
      });
    } catch (err) {
      console.error("Failed to patch station:", err);
    }
  };

  const addPath = () => {
    if (!nPath.name.trim()) return;
    const newId = Math.max(10, ...floorPaths.map(p => p.id)) + 1;
    floorPaths.push({
      id: newId,
      name: nPath.name.trim(),
      role_type: nPath.role_type,
      department: dept,
      active: true
    });
    setAddPathM(false);
    setNPath({ name: "", role_type: "DIRECT" });
    tick();
  };

  const addLine = () => {
    if (!nLine.name.trim() || !nLine.path_id) return;
    const newId = Math.max(10, ...floorLines.map(l => l.id)) + 1;
    floorLines.push({
      id: newId,
      path_id: parseInt(nLine.path_id),
      name: nLine.name.trim(),
      active: true,
      active_half1: true,
      active_half2: true
    });
    setAddLineM(false);
    setNLine({ name: "", path_id: "" });
    tick();
  };

  const addStation = () => {
    if (!nSt.name.trim() || !nSt.line_id) return;
    const newId = Math.max(10, ...floorStations.map(s => s.id)) + 1;
    floorStations.push({
      id: newId,
      line_id: parseInt(nSt.line_id),
      path_id: floorLines.find(l => l.id === parseInt(nSt.line_id))?.path_id || 0,
      name: nSt.name.trim(),
      side: nSt.side,
      station_number: newId,
      active: true,
      active_half1: true,
      active_half2: true,
      status: "OPERATIONAL"
    });
    setAddStM(false);
    setNSt({ name: "", side: "ODD", line_id: "" });
    tick();
  };

  const deptPaths = floorPaths.filter(p => p.department === dept);

  const getDisplayRoleName = (pathName: string, deptName: string) => {
    if (!pathName) return "–";
    const u = pathName.toUpperCase();
    const isIndirect = u.includes("WATERSPIDER") || u.includes("DOWNSTACKER") || u.includes("UNLOADER") || u.includes("UPSTACKER") || u.includes("CAGE");
    if (!isIndirect) return pathName;
    const prefix = deptName === "INBOUND" ? "IB " : "OB ";
    return prefix + pathName;
  };

  return (
    <div className="space-y-6">
      {/* Controls Bar */}
      <div className="flex justify-between items-center bg-white p-4 border border-gray-200 rounded-2xl shadow-3xs flex-wrap gap-4">
        <div className="flex items-center gap-4 flex-wrap">
          <div>
            <span className="text-[10px] font-extrabold text-gray-400 uppercase tracking-widest font-mono block">Station Setup Panel</span>
            <p className="text-xs text-gray-500 mt-0.5 font-sans font-medium text-indigo-600">
              Showing placements and structure for the selected half shift below.
            </p>
          </div>

          {/* Half Selector Pills */}
          <div className="flex bg-gray-100 p-1 rounded-xl border border-gray-150 font-mono text-[10px] font-bold">
            <button
              onClick={() => setSelectedHalf("half1")}
              className={`px-3 py-1.5 rounded-lg border-none cursor-pointer transition-colors uppercase tracking-wider ${
                selectedHalf === "half1" ? "bg-white text-indigo-700 shadow-3xs font-bold" : "text-gray-500 hover:text-gray-900"
              }`}
            >
              1st Half (H1)
            </button>
            <button
              onClick={() => setSelectedHalf("half2")}
              className={`px-3 py-1.5 rounded-lg border-none cursor-pointer transition-colors uppercase tracking-wider ${
                selectedHalf === "half2" ? "bg-white text-indigo-700 shadow-3xs font-bold" : "text-gray-500 hover:text-gray-900"
              }`}
            >
              2nd Half (H2)
            </button>
          </div>
        </div>

        <div className="flex gap-2.5">
          <button onClick={() => setAddPathM(true)} className="px-3 py-1.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-lg text-xs font-semibold cursor-pointer transition-colors shadow-3xs">
            + Path
          </button>
          <button onClick={() => setAddLineM(true)} className="px-3 py-1.5 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors shadow-3xs">
            + Line
          </button>
          <button onClick={() => setAddStM(true)} className="px-3 py-1.5 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-lg text-xs font-semibold cursor-pointer transition-colors shadow-3xs">
            + Station
          </button>
        </div>
      </div>

      {/* Accordion Layout */}
      <div className="space-y-4 animate-fadeIn">
        {deptPaths.map(path => {
          const pathLines = floorLines.filter(l => l.path_id === path.id);
          const isExp = expPaths.has(path.id);

          return (
            <div key={path.id} className="bg-white border border-gray-200 rounded-2xl overflow-hidden shadow-3xs">
              <div 
                className="flex items-center justify-between px-6 py-4 cursor-pointer hover:bg-gray-50/50"
                onClick={() => setExpPaths(curr => { const n = new Set(curr); n.has(path.id) ? n.delete(path.id) : n.add(path.id); return n; })}
              >
                <div className="flex items-center gap-3">
                  <div className="w-8 h-8 rounded-xl bg-indigo-50 text-indigo-700 text-xs font-mono font-bold flex items-center justify-center">
                    {path.id}
                  </div>
                  <span className="text-sm font-semibold text-gray-900">{getDisplayRoleName(path.name, dept)}</span>
                  <span className={`text-[9px] px-2 py-0.5 rounded font-mono font-bold uppercase ${path.role_type === "INDIRECT" ? "bg-purple-50 text-purple-700 border border-purple-100" : "bg-blue-50 text-indigo-700 border border-indigo-100"}`}>
                    {path.role_type}
                  </span>
                </div>
                <span className="text-gray-400 text-xs font-mono lowercase">
                  {isExp ? "Collapse" : "Expand"}
                </span>
              </div>

              {isExp && (
                <div className="px-6 pb-6 border-t border-gray-100 bg-[#FAFBFD]/30 space-y-4 pt-4">
                  {pathLines.map(line => {
                    const lineStations = floorStations.filter(s => s.line_id === line.id);
                    const isLineExp = expLines.has(line.id);

                    return (
                      <div key={line.id} className="bg-white border border-gray-200 rounded-xl overflow-hidden shadow-3xs">
                        {/* Line Trigger sub-row */}
                        <div 
                          className="flex items-center justify-between px-4 py-3 bg-[#FAFBFD]/50 hover:bg-[#FAFBFD]/80 border-b border-gray-100 cursor-pointer"
                          onClick={() => setExpLines(curr => { const n = new Set(curr); n.has(line.id) ? n.delete(line.id) : n.add(line.id); return n; })}
                        >
                          <span className="text-xs font-bold text-gray-800">{line.name}</span>
                          <div className="flex items-center gap-2" onClick={e => e.stopPropagation()}>
                            <button
                              onClick={() => togLineHalf(line.id, selectedHalf)}
                              className={`px-2.5 py-1 rounded-lg text-[9px] font-mono font-bold border transition-colors cursor-pointer ${
                                (selectedHalf === "half1" ? line.active_half1 !== false : line.active_half2 !== false)
                                  ? "bg-emerald-50 text-emerald-700 border-emerald-100" 
                                  : "bg-red-50 text-red-700 border-red-100"
                              }`}
                            >
                              Line {selectedHalf === "half1" ? "H1" : "H2"}: {(selectedHalf === "half1" ? line.active_half1 !== false : line.active_half2 !== false) ? "ACTIVE" : "OFF"}
                            </button>
                          </div>
                        </div>

                        {/* Station placements in columns */}
                        {isLineExp && (
                          <div className="p-4 bg-gray-50/50">
                            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                              {lineStations.map(st => {
                                const activeAsn = GA(st.id, selectedHalf);
                                const isHalfAct = SA(st.id, selectedHalf);

                                return (
                                  <div key={st.id} className="bg-white border border-gray-200 rounded-xl p-4 shadow-3xs flex flex-col justify-between space-y-3.5">
                                    {/* Header Name */}
                                    <div className="flex justify-between items-center pb-2.5 border-b border-gray-100">
                                      <span className="text-xs font-bold text-gray-950 font-sans">Station {st.name}</span>
                                      <span className={`text-[8px] font-mono font-bold uppercase border px-2 py-0.5 rounded-full ${
                                        st.status === "OPERATIONAL" ? "bg-emerald-50 text-emerald-700 border-emerald-100" : "bg-amber-50 text-amber-700 border-amber-100"
                                      }`}>{st.status}</span>
                                    </div>

                                    {/* Placement detail row */}
                                    <div className={`p-2.5 rounded-xl border transition-colors ${activeAsn ? 'bg-indigo-50/15 border-indigo-100/60' : 'bg-gray-50/45 border-gray-150'}`}>
                                      <div className="flex justify-between items-center text-[9px] font-bold text-indigo-800 uppercase tracking-widest mb-1.5 font-mono">
                                        <span>Placement ({selectedHalf === "half1" ? "H1" : "H2"})</span>
                                        {activeAsn && (
                                          <button onClick={() => clrSt(st.id, selectedHalf)} className="text-[10px] text-red-500 hover:text-red-700 font-bold p-0.5 cursor-pointer">✕</button>
                                        )}
                                      </div>
                                      
                                      {activeAsn ? (
                                        <div className="text-xs">
                                          <div className="font-bold text-gray-900">{activeAsn.name}</div>
                                          <div className="text-[10px] text-gray-400 font-mono mt-0.5">@{activeAsn.login} · {activeAsn.path}</div>
                                        </div>
                                      ) : isHalfAct ? (
                                        <button onClick={() => setManModal({ sid: st.id, stName: st.name, pathName: path.name, half: selectedHalf })} className="text-left w-full text-indigo-600 hover:underline text-[10px] font-mono font-semibold cursor-pointer">
                                          + Place Associate
                                        </button>
                                      ) : (
                                        <span className="text-[10px] text-gray-400 font-mono italic">Offline (Check state)</span>
                                      )}
                                    </div>

                                    {/* Action controls footer */}
                                    <div className="flex items-center justify-between pt-2 border-t border-gray-100 flex-wrap">
                                      <span className="text-[9px] font-bold text-gray-400 uppercase tracking-widest font-mono">Service:</span>
                                      <button 
                                        onClick={() => togStActive(st.id)}
                                        className={`px-2.5 py-0.5 rounded text-[9px] font-bold border transition-colors cursor-pointer ${
                                          (st.active_half1 !== false || st.active_half2 !== false) 
                                            ? 'bg-emerald-50 border-emerald-200 text-emerald-700 font-bold hover:bg-emerald-100' 
                                            : 'bg-red-50 border-red-200 text-red-700 font-bold hover:bg-red-100'
                                        }`}
                                      >
                                        {(st.active_half1 !== false || st.active_half2 !== false) ? 'ACTIVE' : 'DISABLED'}
                                      </button>
                                    </div>
                                  </div>
                                );
                              })}
                            </div>
                          </div>
                        )}
                      </div>
                    );
                  })}
                </div>
              )}
            </div>
          );
        })}
      </div>

      {/* Manual Assignment pop modal */}
      {manModal && (
        <div className="fixed inset-0 bg-gray-900/40 backdrop-blur-xs z-[1000] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-gray-200 max-w-[400px] w-full p-6 shadow-sm">
            <div className="flex justify-between items-center pb-3 border-b border-gray-100 mb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest font-mono">Place Staff: Stn {manModal.stName}</h3>
              <button onClick={() => { setManModal(null); setManBadge(""); setManMsg(""); }} className="text-gray-400 hover:text-gray-600 text-xl font-light">×</button>
            </div>

            {manMsg && (
              <div className="bg-emerald-50 border border-emerald-100 text-emerald-800 p-3 rounded-lg text-xs mb-4">
                {manMsg}
              </div>
            )}

            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest mb-1.5">Scan Login or Badge</label>
                <input
                  type="text"
                  value={manBadge}
                  onChange={e => setManBadge(e.target.value)}
                  placeholder="e.g. 101181 or jsmith"
                  className="w-full text-xs font-sans p-3 bg-gray-50 border border-gray-200 rounded-xl outline-none focus:bg-white focus:border-indigo-600 transition-all font-semibold"
                />
              </div>

              <div className="flex gap-2">
                <button onClick={doAssign} className="flex-1 py-2.5 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl text-xs font-semibold cursor-pointer">
                  Confirm placement
                </button>
                <button onClick={() => { setManModal(null); setManBadge(""); setManMsg(""); }} className="px-4 py-2.5 bg-white border border-gray-200 hover:bg-gray-50 text-gray-700 rounded-xl text-xs font-semibold cursor-pointer">
                  Discard
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Path Creation Modal */}
      {addPathM && (
        <div className="fixed inset-0 bg-gray-900/40 backdrop-blur-xs z-[1000] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-gray-200 max-w-[400px] w-full p-6 shadow-sm">
            <div className="flex justify-between items-center pb-3 border-b border-gray-100 mb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest font-mono">Create Path — {dept}</h3>
              <button onClick={() => setAddPathM(false)} className="text-gray-400 hover:text-gray-600 text-xl font-light">×</button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest mb-1.5">Name</label>
                <input type="text" value={nPath.name} onChange={e => setNPath({...nPath, name: e.target.value})} className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-lg text-xs" placeholder="e.g. High Side CRETS" />
              </div>
              <div>
                <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest mb-1.5">Type</label>
                <select value={nPath.role_type} onChange={e => setNPath({...nPath, role_type: e.target.value as any})} className="w-full p-2.5 bg-white border border-gray-200 rounded-lg text-xs">
                  <option value="DIRECT">DIRECT (10hr limit)</option>
                  <option value="INDIRECT">INDIRECT (5hr limit)</option>
                </select>
              </div>
              <div className="flex gap-2 pt-2">
                <button onClick={addPath} className="flex-1 py-2.5 bg-indigo-600 text-white rounded-lg text-xs font-semibold cursor-pointer">Save Path</button>
                <button onClick={() => setAddPathM(false)} className="px-4 py-2.5 bg-white border border-gray-200 text-gray-700 rounded-lg text-xs font-semibold cursor-pointer">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Line Creation Modal */}
      {addLineM && (
        <div className="fixed inset-0 bg-gray-900/40 backdrop-blur-xs z-[1000] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-gray-200 max-w-[400px] w-full p-6 shadow-sm">
            <div className="flex justify-between items-center pb-3 border-b border-gray-100 mb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest font-mono">Create Line</h3>
              <button onClick={() => setAddLineM(false)} className="text-gray-400 hover:text-gray-600 text-xl font-light">×</button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest mb-1.5">Line Name</label>
                <input type="text" value={nLine.name} onChange={e => setNLine({...nLine, name: e.target.value})} className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-lg text-xs" placeholder="e.g. Line 9" />
              </div>
              <div>
                <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest mb-1.5">Select parent path</label>
                <select value={nLine.path_id} onChange={e => setNLine({...nLine, path_id: e.target.value})} className="w-full p-2.5 bg-white border border-gray-200 rounded-lg text-xs">
                  <option value="">— Choose Path —</option>
                  {deptPaths.map(p => <option key={p.id} value={p.id}>{p.name}</option>)}
                </select>
              </div>
              <div className="flex gap-2 pt-2">
                <button onClick={addLine} className="flex-1 py-2.5 bg-indigo-600 text-white rounded-lg text-xs font-semibold cursor-pointer">Save Line</button>
                <button onClick={() => setAddLineM(false)} className="px-4 py-2.5 bg-white border border-gray-200 text-gray-700 rounded-lg text-xs font-semibold cursor-pointer">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Station Creation Modal */}
      {addStM && (
        <div className="fixed inset-0 bg-gray-900/40 backdrop-blur-xs z-[1000] flex items-center justify-center p-4">
          <div className="bg-white rounded-2xl border border-gray-200 max-w-[400px] w-full p-6 shadow-sm">
            <div className="flex justify-between items-center pb-3 border-b border-gray-100 mb-4">
              <h3 className="text-xs font-bold uppercase tracking-widest font-mono">Create Station</h3>
              <button onClick={() => setAddStM(false)} className="text-gray-400 hover:text-gray-600 text-xl font-light">×</button>
            </div>

            <div className="space-y-4">
              <div>
                <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest mb-1.5">Station Label</label>
                <input type="text" value={nSt.name} onChange={e => setNSt({...nSt, name: e.target.value})} className="w-full p-2.5 bg-gray-50 border border-gray-200 rounded-lg text-xs" placeholder="e.g. 1-1" />
              </div>
              <div>
                <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest mb-1.5">Aisle Side</label>
                <select value={nSt.side} onChange={e => setNSt({...nSt, side: e.target.value as any})} className="w-full p-2.5 bg-white border border-gray-200 rounded-lg text-xs">
                  <option value="ODD">ODD</option>
                  <option value="EVEN">EVEN</option>
                </select>
              </div>
              <div>
                <label className="block text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest mb-1.5">Select parent Line</label>
                <select value={nSt.line_id} onChange={e => setNSt({...nSt, line_id: e.target.value})} className="w-full p-2.5 bg-white border border-gray-200 rounded-lg text-xs">
                  <option value="">— Choose Line —</option>
                  {floorLines.filter(l => deptPaths.some(p => p.id === l.path_id)).map(l => (
                    <option key={l.id} value={l.id}>
                      {floorPaths.find(p => p.id === l.path_id)?.name} / {l.name}
                    </option>
                  ))}
                </select>
              </div>
              <div className="flex gap-2 pt-2">
                <button onClick={addStation} className="flex-1 py-2.5 bg-indigo-600 text-white rounded-lg text-xs font-semibold cursor-pointer">Save Station</button>
                <button onClick={() => setAddStM(false)} className="px-4 py-2.5 bg-white border border-gray-200 text-gray-700 rounded-lg text-xs font-semibold cursor-pointer">Cancel</button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
