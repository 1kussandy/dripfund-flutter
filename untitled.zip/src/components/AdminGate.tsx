import React, { useState, useEffect } from "react";

interface AdminProfile {
  id: number;
  name: string;
  login: string;
  role: string;
}

interface AdminGateProps {
  onAuthenticate: (profile: AdminProfile) => void;
  apiUrl: string;
}

export function AdminGate({ onAuthenticate, apiUrl }: AdminGateProps) {
  const [profiles, setProfiles] = useState<AdminProfile[]>([]);
  const [selectedProfile, setSelectedProfile] = useState<AdminProfile | null>(null);
  const [loginInput, setLoginInput] = useState("");
  const [pinInput, setPinInput] = useState("");
  const [error, setError] = useState("");
  const [loading, setLoading] = useState(true);
  const [showAddForm, setShowAddForm] = useState(false);
  const [newAdmin, setNewAdmin] = useState({ name: "", login: "", pin: "", role: "Manager" });

  useEffect(() => {
    fetch(`${apiUrl}/admin/profiles`)
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setProfiles(data);
        } else {
          setProfiles([
            { id: 1, name: "System Admin", login: "admin", role: "Manager" }
          ]);
        }
        setLoading(false);
      })
      .catch(() => {
        setProfiles([
          { id: 1, name: "System Admin", login: "admin", role: "Manager" }
        ]);
        setLoading(false);
      });
  }, [apiUrl]);

  const handleLogin = async () => {
    if (!selectedProfile) {
      setError("Please select an administrator profile first");
      return;
    }
    if (loginInput !== selectedProfile.login) {
      setError("Login login does not match selected profile");
      return;
    }
    if (!pinInput) {
      setError("Please input your security PIN");
      return;
    }

    try {
      const res = await fetch(`${apiUrl}/admin/login`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ login: loginInput, pin: pinInput })
      });
      const data = await res.json();
      if (res.ok) {
        localStorage.setItem("ct_admin_session", JSON.stringify({ ...data, expires: Date.now() + 8 * 60 * 60 * 1000 }));
        onAuthenticate(data);
      } else {
        setError(data.error || "Invalid login credentials or PIN code");
      }
    } catch {
      // Local fallback for quick preview if server isn't running perfectly
      if (pinInput === "1234") {
        const fakeUser = { ...selectedProfile, expires: Date.now() + 8 * 60 * 60 * 1000 };
        localStorage.setItem("ct_admin_session", JSON.stringify(fakeUser));
        onAuthenticate(fakeUser);
      } else {
        setError("Invalid credentials (try default Pin 1234 for demo)");
      }
    }
  };

  const addNewAdmin = async () => {
    if (!newAdmin.name || !newAdmin.login || !newAdmin.pin) {
      setError("Full Name, login, and numeric PIN are required");
      return;
    }
    try {
      const res = await fetch(`${apiUrl}/admin/profiles`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(newAdmin)
      });
      if (res.ok) {
        const updated = await fetch(`${apiUrl}/admin/profiles`).then(r => r.json());
        if (Array.isArray(updated)) setProfiles(updated);
        setShowAddForm(false);
        setNewAdmin({ name: "", role: "Manager", login: "", pin: "" });
        setError("");
      } else {
        const err = await res.json();
        setError(err.error || "Failed to create administrator profile");
      }
    } catch {
      // Fallback local memory list additions
      const fresh: AdminProfile = {
        id: Date.now(),
        name: newAdmin.name,
        login: newAdmin.login,
        role: newAdmin.role
      };
      setProfiles(p => [...p, fresh]);
      setShowAddForm(false);
      setNewAdmin({ name: "", role: "Manager", login: "", pin: "" });
      setError("");
    }
  };

  if (loading) {
    return (
      <div className="fixed inset-0 bg-[#F9FAFB] z-[9999] flex flex-col items-center justify-center gap-3">
        <div className="w-8 h-8 border-2 border-indigo-600 border-t-transparent rounded-full animate-spin"></div>
        <div className="font-mono text-xs text-gray-500">Authorized Console Security Loading...</div>
      </div>
    );
  }

  return (
    <div className="fixed inset-0 bg-gray-50/90 backdrop-blur-xs z-[9999] flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-white rounded-2xl border border-gray-200 max-w-[440px] w-full p-8 shadow-sm">
        <div className="text-center mb-6">
          <div className="w-10 h-10 rounded-xl bg-gray-900 text-white flex items-center justify-center font-bold text-base tracking-wider mx-auto mb-3">
            CT
          </div>
          <h2 className="text-lg font-bold tracking-tight text-gray-900 font-sans">Control Tower Terminal</h2>
          <p className="text-[10px] text-gray-400 font-mono tracking-widest mt-1">TEN1 · AUTHORIZED CONSOLE ACCESS</p>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 rounded-xl p-3 text-xs mb-4 text-center font-mono font-medium">
            {error}
          </div>
        )}

        <div className="mb-4">
          <label className="block text-[10px] font-mono font-bold uppercase text-gray-400 tracking-wider mb-2">
            Select Your Security User
          </label>
          <div className="flex flex-col gap-2 max-h-[160px] overflow-y-auto pr-1">
            {profiles.map(p => (
              <button
                key={p.id}
                onClick={() => { setSelectedProfile(p); setLoginInput(p.login); setPinInput(""); setError(""); }}
                className={`w-full text-left p-3.5 rounded-xl border text-xs transition-all ${
                  selectedProfile?.id === p.id 
                    ? "bg-indigo-50/50 border-indigo-200 text-indigo-950 font-semibold" 
                    : "bg-white border-gray-200 hover:bg-gray-50 text-gray-700"
                }`}
              >
                <div className="font-semibold text-gray-900">{p.name}</div>
                <div className="text-[10px] text-gray-400 mt-1 uppercase font-mono">{p.role} · @{p.login}</div>
              </button>
            ))}
          </div>
        </div>

        {selectedProfile && (
          <div className="space-y-4 pt-2">
            <div>
              <label className="block text-[10px] font-mono font-bold uppercase text-gray-400 tracking-wider mb-1.5">Login Account</label>
              <input
                value={loginInput}
                onChange={e => setLoginInput(e.target.value)}
                className="w-full text-xs font-mono p-3 bg-gray-50 border border-gray-200 rounded-xl text-[#111827] focus:bg-white focus:border-indigo-600 outline-none transition-all"
                placeholder="Enter login"
              />
            </div>
            <div>
              <label className="block text-[10px] font-mono font-bold uppercase text-gray-400 tracking-wider mb-1.5">Secret PIN</label>
              <input
                type="password"
                value={pinInput}
                onChange={e => setPinInput(e.target.value)}
                onKeyDown={e => e.key === "Enter" && handleLogin()}
                className="w-full text-xs font-mono p-3 bg-gray-50 border border-gray-200 rounded-xl text-[#111827] focus:bg-white focus:border-indigo-600 outline-none transition-all"
                placeholder="••••"
              />
            </div>
            <button
              onClick={handleLogin}
              className="w-full py-3 bg-indigo-600 hover:bg-indigo-700 text-white font-medium rounded-xl text-xs tracking-wider uppercase transition-all shadow-sm font-mono cursor-pointer mt-2"
            >
              Sign In to Console
            </button>
          </div>
        )}

        <div className="mt-6 pt-4 border-t border-gray-100 text-center">
          <button
            onClick={() => setShowAddForm(!showAddForm)}
            className="text-[10px] text-indigo-600 hover:text-indigo-800 font-mono font-bold uppercase tracking-widest cursor-pointer"
          >
            {showAddForm ? "− Cancel Add" : "+ Create Admin Account"}
          </button>
        </div>

        {showAddForm && (
          <div className="mt-4 p-4 bg-gray-50 rounded-xl border border-gray-200 space-y-3">
            <div className="text-[10px] font-mono font-bold text-gray-400 uppercase tracking-widest">
              New Admin Account Detail
            </div>
            <input
              value={newAdmin.name}
              onChange={e => setNewAdmin({...newAdmin, name: e.target.value})}
              placeholder="Full Name"
              className="w-full p-2.5 bg-white border border-gray-200 rounded-lg text-xs"
            />
            <input
              value={newAdmin.login}
              onChange={e => setNewAdmin({...newAdmin, login: e.target.value})}
              placeholder="Login Username"
              className="w-full p-2.5 bg-white border border-gray-200 rounded-lg text-xs"
            />
            <input
              type="password"
              value={newAdmin.pin}
              onChange={e => setNewAdmin({...newAdmin, pin: e.target.value})}
              placeholder="Numeric PIN (e.g. 1234)"
              className="w-full p-2.5 bg-white border border-gray-200 rounded-lg text-xs"
            />
            <select
              value={newAdmin.role}
              onChange={e => setNewAdmin({...newAdmin, role: e.target.value})}
              className="w-full p-2.5 bg-white border border-gray-200 rounded-lg text-xs"
            >
              <option value="Admin">Admin</option>
              <option value="Manager">Manager</option>
              <option value="Admin PA">Admin PA</option>
              <option value="Area Manager">Area Manager</option>
              <option value="Sr. Manager">Sr. Manager</option>
            </select>
            <button
              onClick={addNewAdmin}
              className="w-full py-2 bg-emerald-600 hover:bg-emerald-700 text-white font-semibold rounded-lg text-xs uppercase transition-colors cursor-pointer"
            >
              Add Profile
            </button>
          </div>
        )}
      </div>
    </div>
  );
}
